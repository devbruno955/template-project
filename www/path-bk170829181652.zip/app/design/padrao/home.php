<?php  
		require_once("include/head.php"); 
	?>
 
	<body>
		<div style="display:none;" class="tips"><?=__FILE__?></div>
		
		<div class="tail-top">   
			<?php
				require_once(DIR_BLOCO . "/header_home.php"); 
				//require_once(DIR_BLOCO . "/bloco_busca_topo.php");
			?>
			<div class="ImageTop"> 
				<?php 
				 //require_once(DIR_BLOCO."/video.php");
				require_once(DIR_BLOCO . "/bannerhome.php");  
				?>
				<?php require_once(DIR_BLOCO . "/bloco_busca_home.php"); ?>
			</div>
			<div class="mainhome">
				 <?php    
					require_once(DIR_BLOCO . "/autenticacao.php");  
					require_once(DIR_BLOCO . "/box_mapa.php");    					
					require_once(DIR_BLOCO . "/bloco_anuncios_destaques.php");  
					require_once(DIR_BLOCO . "/bloco_banners_meio.php"); 
					require_once(DIR_BLOCO . "/bloco_cidades_destaque.php"); 
					require_once(DIR_BLOCO . "/bloco_noticias_destaques.php");
					require_once(DIR_BLOCO . "/bloco_botao_anuncie_rodape.php");  
				 ?>  
			</div>
		</div>
		<?php require_once(DIR_BLOCO . "/rodape.php"); ?>
	</body>


<script type="text/javascript">
var lmdimgpixel=document.createElement('img');
lmdimgpixel.src='//secure.lomadee.com/pub.png?pid=22753463';
lmdimgpixel.id='lmd-verification-pixel-22753463';
lmdimgpixel.style='display:none';

var elmt = document.getElementsByTagName('body')[0];
elmt.appendChild(lmdimgpixel);
</script>




</html>
