
<div style="display:none;" class="tips"><?=__FILE__?></div> 
<div>
<?
echo str_replace("../..", $ROOTPATH, $INI["bulletin"][0]); 
?>
</div>