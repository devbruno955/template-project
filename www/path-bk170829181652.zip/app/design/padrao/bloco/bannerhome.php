<div style="display:none;" class="tips"><?=__FILE__?></div>

 
<div class="content-partner"> </div> 
<div class="page-background"></div>
 