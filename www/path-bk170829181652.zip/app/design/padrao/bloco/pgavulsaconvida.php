<div style="margin-top:11px;" class="pgavulsaconvida">
 <div style="display:none;" class="tips"><?=__FILE__?></div>
 <B style="color:orange;"> Como Funciona ?</B>
 <br><br>
 
 Sempre que um de seus convidados fizer a primeira compra no <?php echo utf8_decode( $INI['system']['sitename']); ?> , voc� ganhar� um cr�dito de R$<?php echo number_format($systeminvitecredit,2,',',''); ?> para a sua pr�xima compra. 
 � a nossa maneira de dizer "obrigado" por espalhar a not�cia! O seu cr�dito pode ser usado na compra de qualquer promo��o do <?php echo utf8_decode( $INI['system']['sitename']); ?>  e n�o tem prazo de validade. 
  <br><br>
  
 
  
 <B style="color:orange;">QUAIS S�O AS REGRAS ?</B>
 <br><br>
 
Voc� receber� uma notifica��o dentro de 24 horas que um convidado fizer a primeira compra. O desconto de R$<?php echo number_format($systeminvitecredit,2,',',''); ?> ser� aplicado na sua pr�xima compra no  <?php echo utf8_decode( $INI['system']['sitename']); ?> . Se o valor desta compra for abaixo de R$<?php echo number_format($systeminvitecredit,2,',',''); ?>, voc� poder� utilizar o restante do cr�dito da pr�xima vez. Lembre que voc� pode convidar quantas pessoas quiser! 

</div>