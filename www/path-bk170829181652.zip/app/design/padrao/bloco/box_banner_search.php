<div style="display:none;" class="tips"><?=__FILE__?></div>

<?
$banner = $INI["bulletin"]["topotodos"];
$banner = str_replace("../../", "/", $banner);


?>
<div style="margin-top:5px;text-align:center;"><?php echo $banner ?></div>