 <?php 
	
	// De acordo com as novas regras do facebook, uma altera��o no plugin foi necess�ria para se adequar as novas medidas estabelecidas de acordo com o link
	//https://developers.facebook.com/docs/reference/plugins/like/
	
	/*
	After July 2013 migration, the Like button required an absolute URL in the href parameter.	
	*/
	if($INI['other']['box-facebook'] != ""  ) { ?> 
		  
			<div style="display:none;height:35px;width:100px;" class="tips"><?=__FILE__?></div>  
			<div class="body" id="deal-subscribe-body" style="margin-top:10px;background:#FFF;width:224px;margin-left:-4px">
				<script src="http://connect.facebook.net/pt_BR/all.js#xfbml=1"></script><fb:like-box href="<?php echo htmlspecialchars(stripslashes($INI['other']['box-facebook'])); ?>" width="210" height="370" show_faces="true" stream="false" header="false"></fb:like-box>
			</div>
	  
<?php } ?>