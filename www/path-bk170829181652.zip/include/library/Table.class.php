<?php //00d49
// *************************************************************************
// *                                                                       *
// * Vipcom - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *                                      *
//                                              *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: falecosco@suportevipcom.com.br
// * Website: http://www.vipcomsistemas.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n+�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n+�o +� um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran+�a de  *
// * autentica+�+�o por licen+�a, uma v+�z que voc+� comprou apenas uma licen+�a *
// * de uso para um dom+�nio. Portanto, voc+� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc+� precisa para *
// * alterar, mudar c+�digos, est+� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom+�nio,   *
// * nos envie um email informando o novo dom+�nio.						   *
// * N+�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica+�+�o de um dom+�nio n+�o registrado com a sua identifica+�+�o,     *
// * poderemos estar bloqueando a sua licen+�a sem devolu+�+�o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   * 			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPoyr14uNjVnXuDYHRNs4mq2Kk7CBWdIpi2Bk2bFWZwabq3W97uvgu8xfFYSN3m85p5E2x+/+
BHHr1gv/6TpZYD+imJLQrfsS/9JsQkuQUVrRUD6fg6QcGojyPcuOhlC3NuoTWSXMOAUim+hoYWrw
kVLrtb1MgkSVQGsXgmkB+cTkiQkNmq7zRZ/ZpHwkEtkHbr5Nu64XWqv44COSIjTYpyB5W19Ihn9G
IGT5ivFrtNWe1uvEVE8msgp/dlRfL++Cjdt5pdn/Ro5lDfO9K7iKUGSLNpIsMPYEPbUTjv5P5mMB
xxrMoobX89OIp87+z0i6SUdLJNm+nw79ye1/1T3u1kzaICEYc/WOPMRbs86Nt24e34S7amAItI3e
aI99LlcH+ec039rL0QDWT7ri9TviHloO/Eb6jdRnXSXdmkWghyQwr38L+gX+r4zOV0Yx62HjHi2t
SkDoZbyl0cFK4rpDw1eazL1GAn2XFVc1y0bqsq/JnkIGEe2bok3nVpjM0vlb/4h1wdVXJ+cwAAha
FPgBDYB1Zf6WDH9BGYH2lCKlBYpwNXAmI8lqUa4nZw0f7JgsOj2755MiuwzTAZa5LO7Z3Afodc5H
l1n6LtuB385L/+4WRpWOd0Dbvuy3wA0wd2L/xsw9PZxlGQni6Qowkxzocr59O4DFLLbz3EKJtJjH
lyggqd1OSH00jzrKbIZkweNrjLRHsR2jsOkKKzfG/Jc78uIqgtpxw31MMo04CO8YkrIUVIQWPJNT
GRTwOx9rBTcOjwv5L/MBqYKqeuqT/1bj6yTixFJ2y7/H2CcI1osFE59kpBAMr3flHtuCaToqA3qj
K45B8nbqGu/pabawxueWKqEmKSjvcryt4HEZ9jw4yaMlvogpWUzXE0cyYU/NWFWIgBdoHmK705DE
cF791Qis2ZD0XXw7VqiaCSFtPG9BAZwzIb4zQ9eri8UYmykEs0qvWKLE6IwZ/Hz0Vrra0i/2L0IS
ed3ybRtZFOoE0cf+yRPoUakr+lIBnSmzGRD7t9d+XqRc+yewrYTG9kYfcLr84relu5CWLjQ51Kqo
EguYoIOTvXHxX+MfSTr10n+f15vz4UxK4NH8Gv/7HpNEpQ6D7jyOfZ3fIPTd5nJJvaOuQER5KsVj
oXLmmLuCIhpKSaWjFz2qohtN3HBML+dQQatqUNbbXinMqJUZFk0De0FaYR3uaFdjmNj0YBCTzjjy
nAVCeQitLyf+/m0Lg4mV162wda8IVomiE4GuUhxdrT6p4Wha9aQ/ZoIX3f7DXIgL85ONumi/uqig
HzKfsvzk7gkO6U3QKIQHCWt89i0zXJ/rVrcUZIODc9EITrBG2hDrkoennZ0JtPeoyjkeBuU3IaP+
Jgu8nNyCdf1CKp7EwnK9I0iJzPr4zABY0MtkK9B/gKcI5CJjhLZhNNFTRi5qrkjGIHRgXzW2n5jW
hb2eazj5hA8AvOWCouA6XBRO2nvleFAP4JAbn7FuiXgJAkE+9HN0rhI07eiZvC1KdTF90NZPjV1p
vHz18y9hUHT1YFE1HAup21oZlBIzPK9FJeuIohe7u4FH7SsEIXgQKPNrqrBfX8LPHYloWqCu11K3
/68G2NUFiCgBdMqOwEJlBtz8//wP3OZfFWA6JSn7HttenKT3fb66ePKo6z32fDcWJoRakcpo/Ldt
qyvbyvUfnro5oWOC91aGMgKJokQcYBZo4Osi9AUp29Lnng/JVdNNaJSAKoQuqct4vWUeJPzDNuFF
OakgjbyUnYQ80m9N8gJYSr6yZxLKAA9NLr4M7gI+cGeeAsAhP5ncOtDUHO68C1tjMnsNeXRIs4u5
17g55E6Fo1lnxUYnglrpTfuoP4/GSHEDk205wEhH85JrKrIdMIONoOdJG1+SoXg7RGbE0b+HGZ8H
WLlFQLlWA9JFzRzyY4ZoKhEIxWrTNqG0G8tZS/QDKRO1rDCXLm+p1RJoe2NLb7/fG+99ocFMIpCr
eCGKH29ADWEYQN/znxmrSEySiHZVmQKma9dUk6ss6wE/BYz0PttS2gFAn1Wis011Uf7yMPSmb9h4
ZUqK0JGQT7SwP2dQt0USqi6vzbt03C9Jelwksc3HKobYL0m8/j7siIGcDje0DcCLBCNy2Ty9N/Hk
yA8uPYURW+hDcFTZpjbQnvq7HTvFbK31Pn0dotdjqCMDYWoZJkeb4VOauYG/JbpCPoVzDDuXbCD/
ky1S9m414aTSckzbYl0cYb0lBbEdpLsXFYonYpO6wr2dKQZmj+VJUgwadPVCcbREzNXil1yLD1Wc
rOE6QuMHNMpIKYM1GrVbpHtC0b0COpArLvTOIdeKAI5JzrPNh6YEmld7CHQGot9N9aGYgfi9LNoU
2vNiWmfmCbn+J8vtraitkYo5hEF61kfrXeX7efmaFb3KW7i0bYP9lyEOxAik/Asi3KnOiHcFmYOw
t859kMEUAniSx760AGM2ldv/mOZ5UyyjG0GuFoY2iQCSOhirNFiChlz35hsrs9aASrqF34NVuuPJ
QRLbSi6EmjG5LrKTFVjKOmxky1waIehGs4YJg7JUGJU5X929ZBKsil+u23ElpNEFSo0ps1JB8Gau
wP4WFY79BzKkB/jssE4ZDgRARlEA9k49/gu0NNMSktbAGO8I5vkAPkhi0HH/pxh4iRt+L+oWhuXZ
HBR+kA9tEQsffC5OtK5ycvNdTfBBO7NnKHVoXcLB5Mmet0yDxCYTGZQPdoUimdctHEPqgZ8lTysI
zLi4mwNAwuzaDaD30V/zteWcNUMuw7S+bh9BmMJLqlCh/hPAFwB+sDYwADzIw45EdQYW+YYukS4m
mYrAshX+XNldd0oNeNwxKxFaaEoAuySal53gTOm89DS2iQHc+KUs0idyA969AVgm4/nmEagO7Rhr
oQM57DOA7zaTA7uZ1S6FpM4H2muGMlulzQ/dh+u5bAJ6j7AZsOpaKfRkBTjlUhHrndGFtn36gA4G
3kN+xtdHTvfzobsnRw6gNjjE1w0XcPcjFjRa1Z4RjPM/yFmIs5sN39CvzQ96/C8B2Prg/Eex5khI
tGNi1DjyzxL7Wnl48WovKFEct3HkbzsSfPOzgTwq4kRwOA+X6ecIPxTZ0p+3XOFnUoKNXxL1HaAL
eZKRZuwUPmSijx5pLMKeBwHDtz2ZIL8gYrktchJccxfvZsx0lfyLGiszYmAQ6VYk4/E533rS+WBC
nDKBbV1v53MIHVvcsRdTz/DuI6LO6rDTxeaYZMXc5+0HTrTj8hZgo0MsLos/0x1MbjSFMn+CUz5F
iYYfGAP9j+E5Ay71iNQYl887RPsBtqVeeaCU7CsQvG8Iqj8jRYMpZw+tJ1OBkXN6pPQsqlIC0N9v
Uo7abR/+cNbFHNh27lj1rxwerNJPIN8f4bFbo0UBb8Z+7WfMlu5iMVipRuJ30aSVkW+JyHnQLAi5
pClqZupTxfGV9SfJ5bSm2Ic6Lgk1zYxcRHEBmF19uuMDAeOPn9IIWLmEBYgg4OiaZvgaAOYcuNkT
jL5Tg1lDIKpu48PnmTQUCTJvo1yuDTwR/EGP04A8CstvDZFYBa8ffwdJEHGBo2bHhZ0dA+9xLQYQ
q8T6w4RGVjRFjrToOKGog8CLQzD5f+8zQdluao4zkNoU1HH99HtBckRgoD+xE9DxS9JFWE2z2C1T
c3Jl9k6S3bsKz1gSOwUEOoQswPJEea0UvMavp9yVDSQmgc7n7Rc0fWLI03QyTnwHn7vEOR/zONg+
h0z4pGHYk7H7z01I7vyZQC1N+uTvwLNxRuQENJ41cv7pMHPfG5knh/3ugkvwjKIUOaOaltGoN0Vn
BF/VJHyHAVemdB/ZFYXgxL6LL4TINUw7iIeQJjnVOHAQ5epR0a6+gc24QUEunFVTsIXb/g1olVkh
HF9f7JZU05YMxWIFvoucOcqRpr1aGBwpXYcniMXmVqQioJuv/8Od5elRFUmUO52Ve/oShuMpJCWZ
fpV0R07ZVXEj8OQp1dIsYHLC19f+ONbSaPywQaPos5FIrbXk5IditU9Gxt1elTEFCAYVDdDvHqK2
CJISDDvzomcjkV/C3hBWJdC3/dh0+ArJg2z06UWT6/3EndpxOeSosmNDqF8Hygmm9HW7k/F6WSUk
aNYrlW1rgvVIxIGJQOMI5n4b6rTW9Ftcrwya2o1E9gb3Cbjqgx5U1K6wsFjXySWf+AxvBhDEGi7K
z9Mw5/aB5KkUbb+OZg4CsEn4xILWCz9PgxFgjS6ildAEnLNf9K2JVnOJTYUXkifdV51+mvgvTs8N
K9gQ4kI4qjcwxp8cmTtJWHt1uHbcAhKnmPd4dKIoiZsspjPajQMWoE89iI8J4coEZqvc9uFC+94n
e4W9dxo3xs2zhq3EgjUt8VnPvrDK+ev7f8qqRgS+DY6PSj3A5yUc8ajIhIv2RwTQ+5h6/ccNOvav
sCBjN3JPDk8BFRYioTlaO3TUIFNG/4YolLkImHZWzEeDTH5BcvcLtM1vu8Fk2vYKz3LIs616i6go
XUWOY4W+mqQL+qi/UWNBzv6hEU+J6LM38aAf9wEDLsOZGP+fjXpxwmltgICDzJMj3Za9EQbvfB4Q
EV97MWDcUBheWNQ81Wqk/1r+1nWE0nsbq9QHCJMYcuX84qFj6LzkIuXxl/+GvHTEth9dX2d0aG10
mifJG8snN97TGu8nXB5dOSycm0FoA/9cLw2Snp3Q4bEDlvOvBs+lhJ5FQ1KvXwNIo28Lmug5KrPc
egd+bZj98z5yvL3OETGpXHZczUcuZW1rYEGD7/GBKgrQix2Dc0PafJNZ5GeTEWTXnHJ13MU/z89I
5vxQB7ZnY9dMkuxBxyNjmDE/37DtndPQ9UEhLkzkdGFIEK5PTYZe0z9BWP/kCNcNwbd46ZKCYKJi
CXgI2f7+wt1ZboGEexThwoI7buBVTDxG8+m8aZdSkJRW286bPm4EngacWc/Z9NNcC9XLIvv6Fopx
yenOMclcL0ClfpgtyPxSyfEEeVAtYWY14zxjS0IEYlYjcv9y+Z8ATU8g4To4YNKrdg++MsqazClo
II2ZhYqNAfmJ9Gdj15NhX/ZikESYVadEZJ2C3Lost+uSjYj09tuaN9IQuf5N8v4B78KeAGWTNbWH
DwieOyfq/ACcKU23GRFUemFPbspVULY3rnyiQOPb5tArnM/LD9VfH1u0DaE8HVf2WUp1YWf3fqfe
8yobWJByIpt2cP3alv84HWzHb7Q7Rr4jmPbwzeLgUhgVwn1fH4sQss8XJ9lhRn8o/As9Z8DQN4Sn
QMoY74y1iyhMZMjvkIgFOqVuo/2rrnTHCY8/NCw4nbHQOrc6PQAv38kPJZEj1H3+4+TDrjMPo1sI
8XFm85eUXkhO1Ds/6oUoy45Fx8wh5Fr0wXRNqCm2+jYe6+88V46fFKyF6mGMtnMdaDqaTIUyr7pp
A3/zT/DtFX0Gb3i2NTZUoMH78/Nkj/bDR68+mLix/w1GFQulbkZlr1MhmuzNwuME66oB5CovGPnH
XgI6JLe4wb0cc6j9HYZ9fCKu1zpDRFqaMofJ6bq8bVwT4CKoJBAwMpJHVr/LTPDJ2M3/UL6PCvOa
TBKUbkPQJjWwrr4M0Y1nEoOmPgbcBZC7BY/taxGhvmrtk2GH0XVoWpg5Jyr334pPXIe/gmbddENP
fqGTlDESf+IzdlQmEEP0XW5QVi0Etk1xooBgRgTK2v3TZl+q4OpSAMeBOQZHPRnAjEh741/rKnBj
UhRqHmr5OgpEl8t2ydfGJlRnVT6d9TrbGKXo86rk+50lSJRW4qduPnhdBqNgEbs+cEKVuh6tOIPC
v/lofD2xzGc4tB5dIMWg3WdmWVyjS5rxEP5AFoynO/DVkijGk/MUBNF8GvIpvP5VYdAU/Yohm6dO
VvuM5ncJ89zRlrUyqS7Hlm/A8AIKEuveRQylW0JTQCfTbMDBlUWIBqDiXMeAc1S6SxsgZyU6bYHG
0uplkQkNtQ1br3aCh+Bj8I+FHOV7UX3BdRmEvq9wZuirivaPP6/N2DmfzVaLG55bpN1cZZsOmbt7
U6/VEXBM55LEhEBNgV8F0V9AOsZLMBqRHs5hHfSEKK15LCdVq7utMezE2O/Q6995bntPcsXNS3EM
79PK6Rbm12wbTCi7R9Msf6qRk2oefxirerCOsV7Ma4OepTiddiERieR5b1OZOCbLLUnh4WQfjVcY
uj+oNvOkvuRzaWSY7+NjAJCgcuYICeRIWl+sRwtqGzHu/El9B1SKzh4Tt4Ivvk+Mei+q94rz///P
XbWfeYbjzl4SjbfJSxQB5TxxvOnglX3z/B/4DiCZ74JawAfqDfXcpiHaewanw4upwg+3EmvB8OEN
OlSOmKs+hfIKz717lX1LSfin0S/SXDaDn0TKEY6Tuk6h4OoELMSjNnQLSZ7Mk31DYccdAOJKtJKF
rq7FWzUBjIKI1kdOnm2I2ZgxLd/OjA04R+8BJ6r+jTo++H3gHzqts6+idzsIwzV2w/WzVvOBhFLQ
tjaVH4vrIHspdcAAlVy4w7d2E0fLKflp+tq0fcFkKoMRMsOEdMPsRj0e0xahwE11JICAe7lmKk0M
Ji2IsU0Y1xuIp6nkmvysi234ea6jgJw1GLWmIFdyNlalqIdUmDXjNwAjLFPYKmTtI8pcvR87YkzJ
Xi/dqhnkyJ1Og0a0MVdyPjtTc5az7CDry13BesDSu4VMYPaDKZ86+kA9NYDcUGygmxoTJcix3ESf
YQoXQ13bz5nLgWfNSLbmRbyoXcE/xtCJY1UFOLScwgwEZhsQaPP/K/3nEXZZuCOhTJJN6AdQ2E1r
0MQLJ1zq86oejOrGFt5MeiImXLY+vmWvsVt1+AXMOxqpHwOFw+IbLz/i+Yc17S6z8JjGZA6fvv1G
JkML97DA5KEunQEvmHAwbSWQvmQAYuzN3KTCec3DbPBSHL6LJmD9aweSAZy8uiqsVCWiIbZLMDxz
q0xR4doWJUzdJuqiyce9n0YpT9OYbdCL9+OoqNWGRRwQTaXI8B8WqYD6rLkZqxWBA3TVCQz7O+0o
vDLTdRykQdg8zwBLDEN4J7u7AtX+2CdgtliB1pWT1yE7Nt2lOIE4GUkmdpkQt+pe3WHgKwCc5RzM
0gGIErzNOeV6+jKPYufYRoC7GLIeT4n1U3IEugsZjf24B8C+vvWj9WqW/eA83RQtfMroRDFBpM8K
809DyjlU0L3Gqt7F18ptSudJC3ITywsZZQGc0QpNepzloVGNAuqKQBOe7KbFtfJMC7zVfsNlOEbK
iqKi/d0+TN9S4cavnt6XpAQdOq9NMKjBfnqX2+WgCQ8o134dx9HiYJGWp5Yb2tvN6hwoN9M/nQe2
oJf1YxrSCJBXnx8Y/B3Ko0EKkK/UycV06668NVEDASjrLYZJ/XD8KZMXkSIngatdDzFLxcCerb1G
KFUI9VsYqPDRGVIPzcfzi6KsGYkZoH/o6x6Pl8D3K0CMchwnRdxWt0FsVAQX+//0AoIL7hMaRvLD
pxBXuY79g++8L1Y1cQzcMl2MujPhFqcFbemaqeB7c8oEZzed7E17gc2RL+lSNYpNll+/YigFu2C8
ZIZvVG8+2U3jJA2dIQa3mvBcSCG8HQLBaETIoCwAjpCHbWIh0NybNaUFQozdPICxe/KvfGncBXnC
MMR7y/Jdi+7Cdw013ysq7GTRlXbPD68idSSzZFlVMpdSBmabRnPAJto5tAVLkUdPMvktHqXX1F1E
upXiCtREKUGMny6JlXsEBeEa+Egb74Ld9KY1BS2Mk3c3cDEa0WpTa0vhBeUaWNlu3/DWZUajiAN8
lpX107LkrXoEH6a31PQA44mFirBuG/IaXOAvILSRpQ0KfvzUd3jiuTRzSC2d3PGY91mArOixdTOp
QXrCTIEQ11hRDuhBR13PmWN9ApsfG26+QZhSVzAt6x7WKow9MxeQVpGSzgRQdcbUOZzs9edj1qJK
+qFjKlGfIABt3VQBV3yF47OUrZY8fYJGJCC10idwFGMsPsYG6bwC6nZkp34WazKjLEv5EC/baWso
in2EhaVyJ1CsgoESjHynO/iaq4gjO1C/2WPIRFR/24cCcCryy84E9a8CTSBEFVGnjPiDXGLEnaKG
22yHxriteR3LRnaVI7OlztlK0Hlwd+i+wdKRfyZ+iXSFDrTTUxQK4d/4I15GCvxGdAsaSOS8zqs8
GFUPq8fQlbQlTyG+9fZIkBglciEzoAykQE+Po0HZDChekymsCrADkee+deA9qtkADcjuUibmsgOo
A61pmAxbaGEegMR7l+pfbPu3whLrwXoLd16+MSjJPgDW+reVmWKtO7vujRb/XCzuRFr0RCLJjoje
76SskQYGJGJwLhFZGiAzncgZeWLlZcc/P00I6GUK4tGH2Hv31zrxtRE+RSvgWAO1QCN5oEsc5Nh9
ZK/IEn06iD1d1tUM+BgMBX7euPVzA0a+ZNcXBvxn6T/3rfW1ZgtpfkYKUrtqWV6wg7VGV/5MU8RG
M0+V+etY4y98XkCkkiL3VjtVpEfy9L6OpBlrmi7fmZamnLJlvr6GWKuZWmVYFItTcljmzfndAva3
tUXzwkovPRnSyc7fSXVR5Wk8DnA60M00OtEvcHuD0/nbsr4cSiePJhxpyb42/rg9dOZk//+Vp+fP
rezm60TftbXVZj7ifG4b4t0kUDAQlNmtnnrGEflArZe+QOQ5ohAoDYQuWGE7Xdp+q/BJZGpBXBBb
aUtS0lyg6OyHTcMASxMUBR++z3eYn1+/baZR8ZhMq6wnvOk6fBmBSZBWik+XOW1NhGq4Y9CKu5Vf
dt2/66InScyeBesziz0Gf3hmIl8ZzObLpfYiRYuMoY49cvwWsMMZTbeBnnycbX56z2no00aelgQj
HCtg0OEtFmC98yqm3+WS0DwBJ/PDi9sa6bA0hfVg61DPUqNtzCzSr2U1R1dw13JCC+xZMM5fVUze
UaiNZakG5q00oQRK6UoaKu/DLug0AM7gBA/z1HNRufJ4I3ADHYrox8s4EXICPTn5/EmODVMtqByJ
XkF2vTlDDRIP3kIvzwt88GQ2wps6RGoPhGaw1ZXFFbSe/ur2KDQ/WTuDhn7ZeJ8fImZyu7Z83RBq
H1ik5WB+aPYgV3YmTB6zuVTu33bty5lXQE0amMfMHBG/4yfs8W2FHIFS1VimnIIi3nlgS3xtKOro
P97Q7jICEY3dcEtSw1Hfej4Yl56RLieatJuB6W+fXMjzyoR3xl8O2F0mOxAqBQ6EOtqqHE5VTnVm
40YSCdx6/10BUAIYWgNxEmfm5ya3I/V2sUmkdjwIUaJVtCKKFhkPYPR+7+uSY2VnJ8NClGQjJ51l
/VisTfL/FmB3mDE5hUl9A5q5y+BqxxSHYTE5XWtjIIA5G76TkusYLfHOkvXc3fzkiIAyCRg/c2ll
ahep9aCn1/BdRFRO5WBCHYfzgSKsrLWwkVQJo6D01LfZ1ise6fbDUSYGU+Daio/f+AHXYJ716eD+
R0T7MC2gGcohZBmGnG3SOUviRFCg9s7ajIhYnBdbHgWG/cxFMSdZTsVrVsv8CHcsRuxRFLS2xu82
UDKBgxt+xVTpFjYZzom4l1v0zqLQhcnAB0PEEdn55gqNbrnm8T1khMROT0LYcDvDgHlie84ob74+
hVqOgWtq+vO936J1nxbLQse3tiXc+3joFXp7Kw0uIwQl9nelphDO7Ek6qWL1Jj54/KO+QPEiDL//
lMn9OV+JnTH/B7rPg6/gbAyNZV8asHq6al6/l3O6v8RjHneVmA/k2LiX/ymcDo0DWONXwnxD/d/N
PvRXt/N9WqAW3vsfmbxJ4d47mtLh2gNmLS2Mb5q92kiZAjvvnHBnmYqnJDQDUtP3ajCqJ1MDRu5N
rp4QDz4nO+NCv23BfHzU+KL5YS8ve+oy1Cxeduz+TNN5odinwE8z/2sPpZSwXE3Cs0aej5ZoAjjy
qHHZCyZtu4NVn9vD0ZWM94cVwWg6+1cwRi49adu0Jk5tANap8YdbDbvmCAetRUf9h7xcxE8fsN6G
TJQLqw3T5l3Co61hqq5Y4UGg4z9Bm6WiXYeII5YkaQRSVwFvdZ5SyGLCDsiWSBt+IIp36u8GOHfH
BTnHRGkeehRuIhPEao45CBo4ojRo6DMDDy/kwI3WeiKLtlVX6M3CpNEFoGrBxdOZeyNk+h1STatb
Qvge+y5gtONg0Cwtc1ndQ2wVm0Mez01Kx9UN4UuaBkfB+LSlWyuWp451LH2jp01ovj35scOHs4/w
YlJx9e768txY/5dhTYh/Lv0H6LEHFg8l+2T4qgp3yxE3RlwOM30TPgkX/2rO30F2YFKKngVl3xHS
urqm3rxVxkIKDYt8mCa33CR7rU8GIrvDWeuAhR5+zTMRHjiE9X3JxFXDGyO6B+gjPF00YKb0oPeT
jJNyjm6e7IyZrDdEEnsRLGTLj2Ie99l4reNG87gQDnJvL4sNT20eix9cwDacJcvT+BrsT5TQoFHK
HB98ZQkqm+USmvpOWPsDRNnXWqvcZ7iTyFTAaOvF9XM/vWhKAQBRgc5XybJptzrkqrELdtZc9yC4
Kb1MCyORBZxyb2T1e2MQwVagjKJXxqv4lry9ZhfYeQPz+9XzxAddZd1Npj/4cKELGm2WRknmTz+m
7oRxgUJPhisSsugYTNcwvABNk+SBd7Wa+xkKxdNSwNWRPftyQQJkH0CChv/PxItbW3lr6mxIxMOm
v0eoWebCSWtOIbhQyPTbMS7KT1RJ5KzGllGC0ffUL4X0QPSv8dPkScM8Doknytlq6HYdiAJSneGT
Y01M25abyd1/hYSOdGBvMnDVyiPJ9s4iCGjGHZIymLo2lWc8QPl3Xi1h1w3j7m7ht1AnjPztLOEj
vkxUSkLGXWmoMsAnQRz753QItQKesbMz+O8uHCDkFwNsayA260suTQR5voAVxTDQxDYQa6DQC4tH
NZk00qh3Xs9gdK8vcJb++7SDJLWN2t7OH1oNWhyiduBdZQo7pvlQmag/rN++ghHweKa292I4YUe8
Poi8e9hXgMm2flb1QJsbELpiNAbazw+cvozCDC6iknzlCV+jWkF9vg3PCGU2idsaec1+nEogkO/s
RWfFIRTVQGpV857DQbb1j4/dfcPH476iBkoYDbt+plnha8qEJdoXZ3DLUog6Cm/9LGiGKOPrJfb/
O0PpudSnQuLY8Ao6AgUYT75cQkaTnWi9OCdLGXrWrjDxDpuJPO9uQYyMmNEbqUpoAcSGixWfPpEB
sBXOq4PEfxeliM4YnQXcAde+L9KSPp0ZN1W6Uw5zgeYahqy45LP+V+JRiveOpPqYloFJawFiWj6f
UipuJIe4RDiYlXouz127p7T/JeyUrL7rZPFrCeGRYAwrIe7Ypb7D0ux34X2KVNGUHeQAxx2fw8u+
JJuBgjVW5/Ew9IdRMYo2tgXhSVsYAz0HUkjflZPbQ3WJz1aJ8lSdfUXh6IP1DSvhP3ZHA9RHDx1c
RmEA5MJ21IJNcZatifQr19qCAEDTdxinGWYE80YRBw8keXVpAF+dQVT+X9H1MyKe0lvLLEENf98T
gyFod/ZP48fTw7ZG+ZV55hfKfFwdQlIl6p3UYeq9EUWkNgw1RiipdKrfa1JXu8ohgvyL9GL/A0CW
AiC4MdXvTY1DzG677Q+47I7vS9RDBOBdkEjXLnxVItCCnfbmnWX5hxWMBmTiPMLnJkRsKDQpaTsB
NnAeBz6Km0mV8DFMyUFAFLi7lnr78sYsEhk5IkvU1XfQrA5HYW1kY5ZP72o7zKdogMolpx24Mn8z
6pTUnI27QJV4ykW2iIj+9LDRunFrpEi0+M8NR+6iPLqT3r7v4Puwza+WFt8Ax3d1KEoYMksgFZR7
8kHIEaZEsA06/vlKmHdRZ5DOGBu03YM3lKTsOGzaBpLi9s5VqPp5dTXbIfgPuNAS416uY9GjnOL4
+0QXbfQvRWc2FVz3LQvVVZOlvsEGt0CnRZkk8VGTP+eNQI4ZCAf4RvygFLq1rGGjHZctlL2QvTME
I35DaBkOeLhgMyfY2aePakzZaAQOFq509DXmEDYdEIqOwNdu1ooaNdQgj1gJCVv/AsLO1cMiIC5Y
tYUobKeQQI4ir9tB0CynS9/RyqSqgrCoWl+cq4fgOEf4ziFa14Sis4IxGsu31oCdim/znPnYsSnW
/c2eOPnPRqwngygpqHe4rD6XJZd0zPmEAIvC+TOqizdOZaLUwHGGTMZapxa/1ugpkFEcLO6X9hN9
e8UL