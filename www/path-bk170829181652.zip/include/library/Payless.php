<?php //00d49
// *************************************************************************
// *                                                                       *
// * Vipcom - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *                                      *
//                                              *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: falecosco@suportevipcom.com.br
// * Website: http://www.vipcomsistemas.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n+�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n+�o +� um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran+�a de  *
// * autentica+�+�o por licen+�a, uma v+�z que voc+� comprou apenas uma licen+�a *
// * de uso para um dom+�nio. Portanto, voc+� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc+� precisa para *
// * alterar, mudar c+�digos, est+� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom+�nio,   *
// * nos envie um email informando o novo dom+�nio.						   *
// * N+�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica+�+�o de um dom+�nio n+�o registrado com a sua identifica+�+�o,     *
// * poderemos estar bloqueando a sua licen+�a sem devolu+�+�o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   * 			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPzgQqB8PIIc5wbH5aKZaXQ5ZG3eq1ibrbqbOMZeNnub15zZwlSGrDaZ16oNtRxc+2S8ZlOUQ
cHpYdUAXqiAG9Lm+l+MXxQID1X1KgaigmzOwm1DmIdTIbD9yUVxrcS2eQmAvLDyAbEyIWKrxfRja
VCOV0VLi4sy/KcbKK2K6YpUhhgdEp65rhRB21OhJJF5289WPhrS25RCb3I+LXE4Csh5EUE+b/OWf
rIKhFrmUm2E1iuUYCFiESgMsfAR5/ND1AIX4r5dsKSqSemPhnBceLD/M7zwvSpq6VYX+HoT1sVqn
RfG5PNM+Qb5RR1of43BSiL5CBIs2rPoBaHmLJbQCqx8RolfZN5XBnv5m22zcocGdMaVncabOD+Jb
VQhkzIrX5pvjCdpOVn3yOR2NylPRjbs4qh60Cy2q11TopjLlNoa/GoonMJI2tLuO2efmCiz7b/Rs
nChNkIRxhFm/bFrsdg4C8boywDLq16pyJOb0QjNrFRmZe4G3iKK4WzEp62gVLKgT4upTCWOY3O0Y
GX806U8Tgt1taBO/dm1oQ0+9kRVekdlqNRKZrBQ7JlRHGriNUR5+bZkPO9uTxN0ErjZVADBUlHn6
LtuB385L/+4WRpWOd0EctaUTz1Fl6uFMTDy9w+Zj6q3O1KwUnSUldqQtMtplSonw/S7v4a8/fWOu
irHkwDDJY/Ez9sZ5B6NFwJ7l61lQuPvZ7or4JsGImwsgS/D1lQRvcoSZ5uHIC5YLNrPUD5FTDv9r
buSh8sUijWAKWxTaBkHH03TjIfX8KJfGicpgf1NhPtAKWecv9VrXO2cm76E5QrTUGpbLUT+tCIxS
wLM4OZLtksU8OC0Wd0JqaNQoj5lpdAPQ6Fz94I7XFKz6v0AKlsXyNAgT58k2ov2/+hwH9KURzuo/
6ZdYivXp94rR/0YzRVCbWfRVhGqz4AzpCovMCWqHa71lC+8dQjEBcJI3+AIiEcTTTO3TIHLKSz4p
J151kZ7wzJ2bhebI/pw07PNWYvQsHi5FWbo+czC1L9iaM2otFcEgEYrY2LqZC2jMTxYUsAycbbB1
F+fn0qXNxXKMLZQfNtVNgE0aXm5/wB2SNo8AUSlcWaJv9gDsYwqVpE47210oKYs9wcxrpb1t2lbE
0i+B4HIgQsrDwvSu3QXsWGIoZgNFdtgkV1Qw9vswDyvjMjAr8xsdtj85KYgad86cAzzhgHGX7MnM
qx25fLcaowL/Vr2xFskthxt8Kmh4npyILb/9t/t3Zw3YNvsUkrm4ZicK42jZxmONhe2twnWeaxNX
G9otYUSsn7ZiRcaoYR3QL0pWpktvkKrAVRsS+M5MUg2bq53gD7Q/Ir0xH7shHdXlOZGDN0f3YXu4
0NTfkLXVhB6LwgOPNG5d9ox46Ak8nyFLurv3hJQEfSy5ZjTPjg+Bvid8AEkG8Yd3ISNrPinB7XO5
MKuwB4FTYzAA3mX3CAoIgKCISkNdQQQuI7S5iI69TYCvrT+o9Z0TC79eCd+glekCgOGE4FQxYYG0
mexWjdg68Z88O+5q7JJlJG1ah2OQIqDZbw2iYSwrjzHFNH55ttp9MbzPYPb4q6GtiMAW0dILAevc
+WY1UZAgqhTJRSGrClhrv2zRzvjt6NwiciY9/UtnCmvi1p6+G9JTJjprrqY08Ux/fbHpzDrTT8cf
QdGUYaH9V3HnPUopLf0FEGnrgKk1Plg2ZFoWlPEPe6nq9plieQ5QBGbcRVwA43NLf3GmADDieN2y
5VwM06vH3ZTAqjupfwYTnKZmT+0XWRjb4iKJmA65J0vXqfFJyR3vYGXPgSPBJCxoYuh0qkViTZAv
v6lq46gKa9jEXr/WUNf882aYG+pxeF9qbQYdeE0TGjnpZksonhsh5m==