<?php //00d49
// *************************************************************************
// *                                                                       *
// * Vipcom - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *                                      *
//                                              *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: falecosco@suportevipcom.com.br
// * Website: http://www.vipcomsistemas.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n+�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n+�o +� um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran+�a de  *
// * autentica+�+�o por licen+�a, uma v+�z que voc+� comprou apenas uma licen+�a *
// * de uso para um dom+�nio. Portanto, voc+� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc+� precisa para *
// * alterar, mudar c+�digos, est+� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom+�nio,   *
// * nos envie um email informando o novo dom+�nio.						   *
// * N+�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica+�+�o de um dom+�nio n+�o registrado com a sua identifica+�+�o,     *
// * poderemos estar bloqueando a sua licen+�a sem devolu+�+�o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   * 			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPuV3FfouXOFJImchluHchYmvEslsbYxCtFWHGGJVGXTdGRQNkb5K70VluapwjLYSbf2LRmki
Bue7Oh7Ac4ECnwKmC62qhV7G2uy7uzgZutMXm/APaCfY03d7QgZ17Y/iKlsu3bS4ouyUq95YXYhL
i1YXnrSGawQA7ton90B97zaPk90gy5wZYcDO9Y3mW4PgYYeZBnlRv1BUcAHHbQxeJOVP3VkSzJUZ
te1d1FVHWRMnk9W6ohnrSUrs128aZRExEnpO6sYVE2lgBy2qfr8kp7iWHarIyUiAkTZcOXwRB1qS
2RjNV7JJ9fglXeHvd/vs2nE0NlpmHqKirDpcqoYY8ORNBKxDxtPg6+NHWip6EIa6P8RpXM8rppGz
aucRR5f9YOZLeLZMNhQdmDKFdIJ++7EiIEZVwZ1EiFNMi2vsu3GBQ8xgQnHHLpOhr1+cGPBzFsnY
8cjKIIHpCGxAOJDcE/ZcvheMgnZKp9TEV05QxVhn/Q8qyVqUVfkvK41kB7u1GFQoDydkz+M68NPS
osNfve2LSvEfUSEHCKqnVTwmfYmFWLDBFMkPX5pBpvgh3PsycEuPqyhh+kxNHVOP6ErGMopEkHn6
LtuBYWiCWLN/uI1lE1YS0y7gfg69mu+Hc9aBsGbFzErl16yCaYkF51DxVU72I0WwOTX7v/WE470+
Gt4NkmCaRnqcU9AYCXok9Udk4omrClH6vW7bO5GHhzlWWGVmOhJql54uT6Oqd7ZGkD7VxXGjAYPm
bUSUGwVH806Cq2LKyYg1yRvRxINIWBPSMe0CXrv1GhEyd+VvZMzaJaMftnkjT77WV2DSanXcVafH
UVcMkPqkWn433wmJVch8SLPa0sY4/GB/GzfwkwTJlg2p9lhyAhnhFyEfQTz0sTTQoGmSP42zYsR1
2INvoj4t+pe4MoX/pNF5AB2H7WQllmUsUCKeH7MGPMj3/3cyDzUDqw/XywS2hRiqB1NezMslvMt6
AgrcHmEUxvEH6L5GbhpHS4Dg3H5XjwvrGfSHeSBV1Oif8WpePHUr1TIZzDOwn7qgiW4oEaY7LZcr
Vq1mBS7eYsmkVn3YKFoQMXvDbLiKtIQNjHzurdv1f8DclmMH7KAkZa94VgtolIDurMvixRZ8sT86
mtuZQJ459+8F8zhF+s5awR9T6MkLqejnaRGtXDtc0PIvH+9SUFNUlUwtFceVnnqOWdKHCl1tCTIW
5yzEUbL/DQQT5dpPtKH9awim+mXugk0hBslGcsgisWY7K0Y3buWdvVAUgU7GYseDEI4uJAoPpsts
gPtIB0I4kkMeco2ognkN1tZcpf7Ln0cKLHyEzLMqsmSCxy6XMc+gh7pQV9N2uXPNN/KzJ/SqLKbT
eAEoN0TgbcEVH1wuJLKqn/oFok6VikAxGlRT9YoOhCpnN4c0ii+TIJdUSFLYqBGaYIHwHo+GTrlc
V5cqxqj2B+BylCCbakC/Fzn50ek1WxjMRYUzfdUN4tFZwnt8fP+dALRrL6GWI0K6ybAqLWaDIfn3
wvaTuxvvATMQ0p6d2AiPNo3YVj3ZQfpW8If0oEOQiQHqYsnTXMyThM5Mc3+Wb+QwSW3OAySsmMiZ
tkxxJsR9KzrlUVQ1K7m+KtFazUxMigxk+pKdvP1UpoUz155QKl1I9ysXehOKy7ZAwXHJ3mWXkDhg
S5lBnQv0dB3HLeAhrS47zHiJ5uX2BynkG5cg2u6S9G+50oD+JFrB+gBmmf4AzBJVSWGjk8xVLbHd
Wlac9eiuewq+PeZDWWz21RkaWB9VWhOgoPL+kGBJJQDtgimRsEh8jX2sXvnq8DozQ0HBnweJTJzu
TYAfCDSFKXixI5W3dR4PjHhMoq4vig6FtFq8L9YxT7US5RIkDBI09NSkks0B1tlc2M45awNucD21
ijWpPM57U2WpK0as+OipraVtZC0p2TIqpbVwMYk1ByAUjKsQi2vFdKFwGpApRwFniPdmzlA1uw0e
BaYGHIQyz4f8fV7LFu2/+UhXLBLSKOS2UShOZgUOtKisqcnh19uctea7HZ9wEkk4Kr+Yp0997I//
EE8T9YffJIixBV1bBp08+jlDr2Ss7edmzkq+EyRNVD7gjvRT5LegAIeE47ySy8W0j78TJGoaJjTb
diJ17BeE1dqgU7mDdRp8ypW1nI4JbLSCpyI99q6SpQpybs18AWzmg2UOlvuDK7Ue91qm/+MHUhJW
03Zlce6mZTiD+W7p9yl2eYjVhegg8bcoI2y+xAg4zXqRDY6VJfpr4YGphPPH4JPOoxllZLW+e0pM
qrILeWEIaPTEQCXxCPXb62ZLvaGTPWEQKY13HRr/UO2J/y4f7Mb3KGCksTeQHyuYTF+jg4lW5DLZ
9XY7XS42BsHyNKJ3XC1OlDDmct2VkVVQlHhn8q9Y4rvKP/ESYwFzXzfIVyL3dftfPlob5jcUcqpw
kzh8za5Zz0aLKxeBzH72sqiFArCz/giE6fH1CeYTcjB3yjBXows3jtmWSWDIvR21+5MEwqlTeOqk
3ADNf8RSdpZueTPyoewXHyYSlJURferNQd+1u2psnOJ7CjAz8BWZk7ZbmWfOBd7KJpR1DHgp4Mvf
IShGUsNBPHkwFgeVr8S5u22Zm6C1+5W9YSnI7TUPPQA1zimBjjCDp+vdMUdIqbEKxk9te5qOPXaL
NJD4miFgPnKDLF6KZbUbcQOrWegY+zFqdXSSf3iW2yjdcrOuw688LxOPvTAJZYfKM0R06ExtgSIn
rFH7lVb7WCUPedU3qnaaPWUb97K85cotATUcnSEgyrE5wItgaOAhz6mTR1tcRtuttja4tHsBL2xT
a1whYYYmJUq/0U0rouK8PgIr41WxLRfHfKBQsOObOLDxoA+jbRcL6x1Uf06qZCYjKj1Xxi+vuBr1
EbS+EoEpkOJWX/RcjP/ySI9CBk0DXtDS45UMoFXOp1Ykqmgpnq/64ccjVL2LrW==