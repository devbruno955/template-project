<?php //00d49
// *************************************************************************
// *                                                                       *
// * Vipcom - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *                                      *
//                                              *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: falecosco@suportevipcom.com.br
// * Website: http://www.vipcomsistemas.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n+�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n+�o +� um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran+�a de  *
// * autentica+�+�o por licen+�a, uma v+�z que voc+� comprou apenas uma licen+�a *
// * de uso para um dom+�nio. Portanto, voc+� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc+� precisa para *
// * alterar, mudar c+�digos, est+� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom+�nio,   *
// * nos envie um email informando o novo dom+�nio.						   *
// * N+�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica+�+�o de um dom+�nio n+�o registrado com a sua identifica+�+�o,     *
// * poderemos estar bloqueando a sua licen+�a sem devolu+�+�o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   * 			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPsgcDBie5OsyEtYXc5VpKKX8TMUKG4/tVjODFMkA8WbvtwMhWVpQWai/FK5BwYtNbavq8tnu
pr0RRjkw4e6ln4v0XSXzDqoQ8S0OgHOZyNj+eRoCJp79ccoIpMbYJGKeqvQSjhmnGa+oGoNu7TxP
krcbfrO5XV3uSEem6b6EYRslXaSI7JeJz92uXdXdaHI+XHzijWUBMZAWLSz7WtqsiImJdcHQao6b
7Msfg2JX6+m2y1XAyxJUMwyERfpaD1I9RKbjA61PAvTH6VQyfNwY1gWkMW83gYG8wsekyxsI9pbv
Gisgrxito63qd9E3eSq4jpulEqtRITyWZc816kpTQQoktmTwEWev/gc4GRYtnQ4AYvMOiBWpc0VA
Qy82fNzj9GdMNgXtnfsHcZeB5+U4dybD9el0M5IkGKR4qpJK3QvIea25FvZrEQr9K1EX3npZiFNk
BQx7UetbD9auix/dV4QnfyXML2b2Y3udwiE6OAUVYN+IP4ReA2m7Velr1I030n+REYEK54DPzX1U
5D1VUOX4vUsF6vCizmjAaWaScBVjH1Q2GQGG8L3EzKNVDzJkOqhSGihMPfqK8QD8MRHuAa7RSNCS
HbT+2mo1LV/X86yu69m31TXRjVSD14KFNel5YIe6x0t/D2B3VXb2w2gowvo9o1Eo1vAJT0pVO2py
6sIaB2FtH0+TWkkfBXuf1VbRlVPabRUld15ALM10zAx3BurpwCmZvxZ9rTypvRKvpe0FEUdxx/pH
UkCSe8lSgU+RZfQNGF35ga21kqmGLxzrmk21uLAyOFCXpaR9kVhvQl8pwRluc0BUaFOG893jXYWi
3TuGrcDA0X1924ntMyR42DXh6qOVWY4fnLth240THOgV1tXdJKe0SO4Sj984ULPGBl6NcZg6Yp7k
v4h4g8s3JqXI32/RIjm65JQ/MXdSfrdh57J1MPDNaUAybSf0NZVI01MghrSspQSrcRu/olxAOEKs
OX75O5pi9aaq5+7SxWbru30bhwmB0MRnZQVQGBZJRzVVFJCZ9kRhJhO276hcAfDnt6FHppMnHocz
/ObxB9XoPynyQ44Fy9fEXGcO3CDUdpFHTb8OKoohv/VoI2ORAotzB82X6w97S2wzqzk5Mc484V3H
SvDUegXIFGNc1fsOhq3HiWbwwoJEEj0sO8A0KHYVaLKeUKAKaSToViHb8StDRQ8/kA8xwM3I30qh
W11O1lzzSJ83aBAjGYNqTAePnyHNRUECCeq6VQHNaHtu+lteu/Y33ohrqDmCsr/SekiHGPd4pkgy
vDBIyNNJKKpktNWDoGgBJ5s6L+XFz+MJadHl4bQcM+FyB5X4KE/zm9kYWeGPUuUcDvguEypaXPq+
zjB9oRERLkDMiT+Ef1Lhgro5UocmVUSe09UBMFBnARdmCeGRh0sKHgHXMm6RIL9JrFo9Ywh8lUyq
GSTXXDSN2pEc74QqZFg5uh/HbzPL44MFn+X83RpxjuX9nDVOna6LlnDsbeeQREqeOq2KlTXqMsJ+
APKwWZ1NAfKSHGkGCydr2hJ29V326oQXUkH229Sj6Z8mlLUpmM1Ku4jAZqDtTKLeldrLiOHi3dHb
Z63cLdfWQ+zGA2mwDNUqb+WQJvMyoNbkBJOf2Lg2IwAlyRKH+O2zEy1uUKhkwvCr3nfIgS8/OLRZ
dm7LMg0IMr98X8zlb/MXv2GsL2oSO8h4y60DV1MbwTu2QCSbwzibMF5LcCt76NV/9civIIqWYvve
SywgD8zV6aIfk44QqPkInK6kfqcb1BZ+uCPELphnccPo9Z8z1oMGIhg8HEYYcMqVHcwFHv62M88Q
eYl0Bt66xyV6FZIgvy26vbZrkTmWfRYhCtaPBoe/a1tQCVC3clNZErxph9PDdtSu26fgjw8VsgAz
c8rfg0LWZ7Co86eg4XqA6TM8laOTzD4bu47VPuInOpV1ckA5W25dxfyYabmCGNLgpZxdJRi536fi
ULzrQlncURzdGqOt+9IEfEeOPUXJqDHXRaB1C9r+3+Xyg7d7WkaLc3ZNsUvbeT1IDcamXTVY7F/W
PUFjgLnPTF3W23J1gs2bEivrdasKDt3F605gab7WGsGJtEs1O2iSM4va5hh6MTODh+91AZB3pipc
kSvLaOlsdgVinSQHzjVu1ZDyYhl/zdoKVDZ6/pzZRCenhgZelbKYhKhw9jbBkTKTcKwq4G6OYS8V
BihyqUbiOhlauBsFt4b04etul7gOuzityQ54H9ymsjkvmvBXCjKp+aVo4xIFwRBSAe4aJXXGRBVG
4BfTlG0CSvrGRqVkfuDG4uECm2rH//McLY2xm+j1zCH1jmXhOf+ytzb4j6t3njo7wFLcSvQ+bE9s
/Mr3qsGZwIQqmXmfqV5w6Rng34Han1MnCt84//PftrSW/GOtS3RvFrr/rLAEmrgor9U0I5axUcGb
Q/EAXcFolJQpECy3dd89rr8zSS8x4wC081RpfQRcFTFkdYQ17+nQvpsxI/llp1NpPZCkL/9aELg+
L2T/hgZ8bxrZ5ghYVYZoOiHvT9l8tyKnUPWWlHh6Zi8cpcBpuG0BnpcLzwlNiCtmaFu+b9Zwm3wc
MmhaRTkKecIHO5NUXluRSQxPFO9vE1pB9r1pU+h5lM1EitIUCMeOPzmoVyOPyyF3sD4d1cQf8WM1
UTiLxulD01QkWj54Mv/Vyt3cbbsw8vBg2uTX2ZYycitzXkWb3KkJswpC+ImsAvxxThwwwz8p3Zft
ncriyXwFEjwzBh5MtWU99hNdIKOTxaiObhUjNP8o/szmujcyzSWS0+ZYf74eTNl9BtdXM6kIf4Jt
+nf52wC88U7dzdOaEuDXREXa4oYQuWNu8iQbwMKpmWM329EW1NuV8fytoS094mU0tULGwx6xhvCf
c7iHueoQaHk7KUQuR/RxZKqmcczcv87npysZ6FB6kuz/KehXxGFjQbNZ9cVmMMNMXtUeJwFVjLuE
0YXvBg+wG2lOA+UxxclU6RlbRc4MHZflkM0MgV721pgbI1+3qi7Sde8TZYl+Q3CC5nfyTUDindcd
DAYBCSXDIR9uUU07z8WNp2ZhJtqeIRrKPNHnJexA5/yvMZi50VurKsyQpBxR57/BjWFchMdkzoU0
KVDvTba1dp+1fQYECBIvEDaSrFq19HD600PCzstVpww76zw2QY0c+QGFl5cNW2IXmha9U+f2NxDM
1il+QvZosuRUa+wAvWEb78iuKf37XQloayY1DvgmVP2IhG6WhSRYGFlzAYk5aHjgD490jUk/d5Fp
tY5pmhtLLpFSxS9nJIoPJ93+uEJUUicMXKyi/ix06ssWlC/EsM8MYIR8lxuxMPfo/dRgIETY/l6b
rptSKH4QXhcykM7+3bAEHx1a3BNle7LRSvkwiEnt1VlHDv2Y6p+7Zn2FyrybBFjSXmAEZ5K39nwF
hi5y/wxP/vv8GkcF0O1K5pLHn1Ao1aZeG+JoiBV6m782H0CTL/I/1bcTD3d//5S83975JC2/3mSU
gfLm8yKcLzEh+wrlgUXd37KSeXiSGP3oodya1yep/LLR3hu8GmnXBA+bINPl+Txhp1QxgaVl1UBU
Mh+7C1QJVfB92pvEjlkC7bPjO0xt8yWanPNbnSuejo22EZvGnkYEmEWVsG9sFi5fpanwKws9HjlT
mjCSJQBtIgHMhC5BKu82Jzn39iGudtLBVybANh5EbCiW0++i7WZXwr07ZiWFsoCEb73Y98oUCv2a
y5faYOcGNHemZ/eDVGHQe22e+pQ8FfBRuo7QJdQleHq+W/fTAtybXax+Dvd0gWh32PS11zwioFeg
88t7BVBD7n9Q5xD0ykiEpINURnwXsoqjN5RTdFYooB2mrR34eEIT06l0qcDFz+inIPbqKEIyt3jD
HTa2H00BcAaNCmdr7VgcDIaxU2I2EnYK4KUK85CfAeQI0qCvG3ZQbXZEE3AtluJpT2CePv1AY9Bh
aYLXhsyHcqTPeN4gT/7gXBtUpg2m+HVcYlMfv/5RySmkf60pAKEffTvkTS0ZfeHT9MG/HISlZpzR
thT3hCsyDffADANhGMHS5JT7yu9VZu4IOJ3G/0vQqLciqkWIjckX/Zihsti2T5LXA2bO4AbhBaiT
YqxRmnWn4l+LnvBdhiTDBB4cEoXmqc1clm/dpU02xuweIyYEgFsLCf3fY5HmANp7CfFcWMdC0DlT
Ox+y51J7vf/JCaNHvAVGK+frgkvOdl6XYvvBz+IhUs/Oe3qWXaRIm7r7FqqmMlnjAr4FjamQFwUA
RVmX4kOUKWOpfGwT5CkA+iyAy+AkeMks18BriI/4VVILyE2zYTvXIi9Ac0vZ+gl2QqPGRu8bUvB6
qqRcMWaqlhwu7NwyNBsXwHjJ6YcidG8EDaT9hzGZofebjuc1SEdks707W6Rquv0z2ATOJkzM1Iwq
qMkcJ8EUol7plo2z6gs9LjUqzbgmujVhtAkR3INwSmq4oj8Y/zcld1Uz9WExepv8v4NPQXmPyb+g
iVdVtPm6r9xIWn1AB3kkSClifTaJGk4E6UnuyBKd9mjy0pB7byk0qYbMOOx0jx/c4xCqmVbu5ttY
QZj+VjDho7AFOkjYEnLdAonttB4FDcPSw5919Fun51n3iLrfG2qKVvxEV2SjzM5qHp5WQsOsV2J8
zqLBMBb/ddtS2BFZvoBZRHjLb0R7vh1Wg4puf0J1w1REKpP2+Fvmt+BImfC/SbgBgU9CxZvx2E9x
fpGQuLawFmViwR+7+TKBbYAhNcM7G95gxCdCga6ionRicBtvLV7PVgLmIPVH5BEDM33hnfQrp6wM
eNF+0mx6e47/RF9OsvOdh39i2WXVJIJF9Y1AILJbj/0rnMGWyhioHc0/2iBFKi8B0XqWGOSCSxDs
iOrbhSn+E3/Lh+7eqI3/46+pfZ1sORK2GbRcv7e1DQQYp7A4Gtm7KTKochDUwc79gjAA6vqoAVE1
x3EsXW6Tm+XKlEWqyi3vzgPa5UN287WFEqNzy1TotHDbfHq09UZv/QubeKHTBGxBO6JENIomwnTo
MWIdgIZF9fjB6iecvId8kzmwRL8mTJEKWJd4OBw8HvNliyqRJMUn8Qx8s0+8GJyfq5/U45+FCo7h
EiM+K5UmLRCXWqsKfQ+vM0pxeO610enYaj+RkKL95X0wQcm6Tl/R8sPvGXJBsRt3j2I9047ekf5O
uX5UBKQ3W27fFp+Iyqj+xFBCuCEiJulTSGEKf7Sqn2IfMZdAytr+saCtUWGRrUggXV6JvUx0y/ke
Cs9gMI9LJG+2IJeDDHY5uYrW3INTXIu5SEEaZ7K9GGZdrLW1tbyS6XoY1audccnj/4P/QuFRYztW
AwSRqE4qhpZB11onj+OxoQXiGr3Tss0Yuj8Qcbb5KuMK6QVH2bss8+T5jiceKZQnENeQAVeooB07
T6FirYQN8lWZ4FUyNEt9/fsaUckdN2V1v3wAPWJy78a3w4S4AufmZNHlai/SYCzhK2q+ud9ssdcS
LNOOx11ZDq4+1ZS9GScWM9uCOEV0tD12XA43a9gseAtBUCsCSvJIex4IR1sMsXc5NxzPQQ0zz7pv
EfaODUPF9ckma8qIcNtPti7cOotK2Ar9lW8USZhmZcoYHPc5LxfjioS0TV73nxmHnTS1W4KZpDnK
LDFZWqIFuS/E+l9SSZyFNt7GmtG1/6xzyNR2PJXSGG3iNXbaq1eaGIwRLWdeVPJOq1t1FJSGC4Wu
lwKs10Svtg+ERLOWz+EsrmeeTqRDIaO4mWm1UWTgvjY58FqDv93f5pMqVRh+yW8s8tAxrrp7a+sn
LCNsIkAvHvRso1oSCMlf21E3kHIO7EA0Y2iGriFc7O9BPNtQxEOCso7D4cGUMaRILhWPFQ0LAuCY
BK+a996CdoHQj1H+r/+5X6ojX51hu29wGtKzxXj+4EXMYq/gA4U3pcRGQomRYz01CBa8BtZIk0h6
uKr6mE/il5rnB/+J+TyV+YwE2q9aRhD2k4vJWOki9j7J38vxiascFYrQbc6aGuHdH+I7DTQQA9uI
k3Z8OqJGrBT+fhDdqyy61CAl/Tftwtxq0S7tOi1/IMmI0W5mlTeYzWqv9YOx0d8vi8SLlN5eTFxu
mrzNDr85wenYEGiSLPMX4OVmyzLbC13k0PHGTZ0FNfDNLFJ6abyeTHiIFUgE+7+cHM6z4+PaBxoI
Kulaq7MIGYMVYTFoFT1ncmy3LgnObAHO1XYmZq9jAvYySbZWC+tGlXkDmr0mndSDBu+KhVAdopXp
bFrD8/AEEfTTKp0/Ndymyx/4WQjhqQ0stQsfKXTP7cVaXw4YoJCqfD6ZiiHSMVH3OtFX97+Vz27W
/RXncmkQpVS+jqznNAPGmojJreyRQK7an+DEzQ9klych1BTDQ52DNZrZtU8Ct9u5YD3QYqHR+kLN
ZLJfPKP65EOaYrChfbxn8Ej7mwW+bl1VKWg6BaghJgqVpGVMdgjuC2ugL4/53SFAuWCMP6MD2A5+
yvgxzkGmuOCvK8HCW7t2cI3YOq8woSn0i8RYU9VrNc7g9LEzCrRhOLLqgY9L00kFENvvTwzG7dEs
ziP+KU/Jwclg7zaUwFsL0AVVb7cOJBAm7WewNDs2+VkOVBITBbQtwg79CtJjUT3IePEnnKSs3ARl
/JGUrrutoM2ltb2nE8+NiyeElwNSnTfXGtYjgsMv3uix7CaBjqHKbKa4icMVWYgt1nYifPz9ZE9l
cHXIX/lb527cmUtldz24EVaXmGjggaGcmcrwjM5WIwVQXBvx9XPe2BZhPhK1g/7wM92av6eFpRfS
a38vTAdAsZOB8wduKmLY7Ne3iioQNZjMZRsIRCw81tM8yy9++g5kDuIOvCxIcC3HpfgG3RbbgjS1
CE25ongah9P+HAr5VQ8JQQmBkDErI1sN1o4W0b3VVMHQ+Yv+fo45uQVem1FOKg1xwa71aR92pZ29
poY13pFJu/7T6IUKqQhTBIQa8m3pAtMDVWYpAZRRp5C78KboEWmi6MGzJucmliBZja84bMC38qzQ
mk2hkFLkpu+acryzPrvtJ1k4maEihT5l3ydR3xUUMqWgkEO0UUBloWsc0e2ZD8QNTJiRfsKZTysp
WRvcUrHke/VKHyFrq9me8cn50pGRofOxqfu/rbYxhQtrdwKDSjs1j1xN3hA0tFvppuFun5edrQ+s
HnVbBMaOw6tOPM0UfdnZqJs6UpTxAh4uuSdKXb5gKU1hyPexRifLqE9+pEOr3gLTdcaW