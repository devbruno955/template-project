<?php //00d49
// *************************************************************************
// *                                                                       *
// * Vipcom - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *                                      *
//                                              *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email: falecosco@suportevipcom.com.br
// * Website: http://www.vipcomsistemas.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n+�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n+�o +� um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran+�a de  *
// * autentica+�+�o por licen+�a, uma v+�z que voc+� comprou apenas uma licen+�a *
// * de uso para um dom+�nio. Portanto, voc+� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc+� precisa para *
// * alterar, mudar c+�digos, est+� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom+�nio,   *
// * nos envie um email informando o novo dom+�nio.						   *
// * N+�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica+�+�o de um dom+�nio n+�o registrado com a sua identifica+�+�o,     *
// * poderemos estar bloqueando a sua licen+�a sem devolu+�+�o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   * 			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPqiS/xRsQBw4+NlbgTKq5tOt0/ibdmRU6/VUM4zq2nO+aiWJKAiJQnxyagTotHUu0gvEvb17
O64vzWOmqEN/++7mjHDAg5TvR51PuiuZBJGv1qujLdK3na1L8kmG7hZ7omyaGsQ3BuBLVA7bfsjR
xKGPr7qiKCfiRNlV4H7bxVlaWj3VJQzB2BxoHMp9K6VLAjp+gS+WRIqzNz/iayrbcqPph6jd+zrO
PbforLeFOsAUdERWFQMpJbJ9Lmf+0TSag/ABxsrs1UXwnGpjkl6gXioV+ozdnDmse5fd3vVYPPw8
uftPyrQU0rNq78i+IOu46CnyflZ2nBNFYTUhG0x0upOA4Nurc+wLBJin1AMsFVidX5X8nzstED1z
H+DN7iRO8KHS5Qhq3imEaXwre5ptQEFyEGDlrkkJjSj2fYsK1N0Oq3tVZABJC2UuJix9UHCk2PiR
cj0dGufflJvAuKml5SORCGhAULAS01heqNnsL9Ms+pRzcVy1RBI8hpc5FmxYs6u3bxPZzjQqJz3l
JQCRTmY1ur6wY+DAjtgtmmGd2+l2We8cUDOO5m3Ax+Jf+fNsKpMk/8+fi2M3rsBAS7jFGXFe74PN
VWiCWLN/uI1lE1YS0uZeB7Zo0MYk+RS7pWcDfkzx/qiRD1BnKXFHsqAcBZXJhlkmu36YGQuzFoNE
aOAEBcHoQtsr/dS+jRXdEp7ZQJi9+Za8u5jOjn/c/EDJReK6RNlRoWLznBRG7OsmAdf2J+vOqgwO
QbbONhk9cne1/Fz+QRa3f8kcaufME8XMrU7bedh2yW2bu+XyTn5uZZxGMLb7YhCmdT/qHIVWjVjH
kEQhufiD/w65gs9RudHDzB7yhfrvPNUq2YYtyeGQm8PS360v+aPqBo2VKbwZxmeZuZbMQr76AStZ
vTNaLcI2t1MeulEssFuxjassU+FkislvLYNnp/f+AL98AH1yy/5VADTWW/DzK+PVp5XS/13bkB2l
/Mh/kNG7HOSaQSVFIYyaKfpqj6BWL1vYr5dbEk0kMhpMyN/FlDU3NLTDE1a2y11hvE7sTfeRhidL
lfmSY0jSDiZGISOoH9Ksj9Y77pkXBvMAzKBx7gQ0CfjwKZuQpklkyyDEyl9dB8ovRUn4aQp268sL
WGJv2prMqa3gD3QpFm2lnR9PEmGOAiLMfnzHh7aDDmDm2MfZ80E1SqjedWr6IcK/qX0JZPeNE7oQ
W6khUyQmVCCmZ1njb3G2gQUzlnBRdVDPyb24ydtgVCPZBSoi0uBpgfihFbeO+FKRAoQdMbDJuyaj
Pbk+GXXov5Ajyf+m2tpcTNLADiYu9HWRqYg/ihtnU401BLK1DEFF9rcYstZG+bc8zqx2aexofeMI
zjVDNUCFkZKl3bUg5HdwIORXi9vHFtDbYzfuxTDNN9XSr5mrkF1Cc6T4TzQengJlvly1yXQgwIBi
xcmgdZcgBYR8VjmLlBm2/tFaRaD0d6FG0zp8R2Sa5S1ZaKUeEHGASCXGOVDZKIshMzOcRgjsm/bF
T2wgQcIZ1qLAO/rFl9Nvs18baBE7T1yRCxcMJ4zPnZGC2KAKJNDb608+Ermdz5UsX3v5HjDQOTut
zufTwtl0grH0MeR4AgdYWfl0qK9HhxURWkC7um45ynYl9pSBVetfPTtTJuHqK4cp4D1h2xZibHp9
z394TZlOEiCiHnemODG3NYbSap3+fR2XBzq/wWyCA7nWlJ76LjTwV6On3+K8Saq88PdbBAVzoXjV
L1GHsLID5j6AC68gS31asUVP88XIU1AUZDeqDqRC2PHNB07pk2xkK8AupIJ3MYHK7UlsmlA6c3x4
aViuPwghK/MKQ6hZsCnCs6o/RpU27W5/Z9UKC2r/s4vLs2eNN4c9rKbAQ0kOixvVyFNIsp8dxX5y
ECkIgI0Nd2DVWoLpyvx9YcWtBdhi4y2Tjbq63UJkrXyhQnxHCdWzHS2ufcwNxxGQON0Ef++jcWWa
/pyNpd6+0x88Q/G94+8sOq7Bc4SoU6UhYu7lIj6JegL6aS4gGujT4l6CscD905rFGyR5CTcygkF8
MOufH52egDfEAES4Lk4/aGbac5GsE+VEcHtjBlEz4VPf4/FDMLe36kxhfEVK5jBSBfOrrjdapgT3
ypYxkuDuFeKsvz1T1agsuvUNzAtaXTFOPa7ZGXuanqK3xhEsqbQpwR6szTvy/28gMcF30i5+D9SA
jmktE4xPOOEMrTWzWzvAXpkYAlkhB2apAw+sKMajTWZmKKPGAOe8ot7n5Lnr/7TQHu+mMZNjeXfX
vl/ksCr/NjB088lyqgtj/w9IpRkjDmzxlgNJde8g45Y/wrwhuG09Qf6kwRL3r+UAS0uUycjdxf7v
5eSEDYDucAjU2CSz7ix5vOV/iS9sgz+MGvOGHQB+b9m4U3fdxSUgLHVUPPfh0F0mskVBzTnJ4kFd
42zDmReClgBtkPopKdHorhCSVGCe7XKkRl3o8P+vmjrWlUpvOH9vfk3alI5i9V+XvIW/We2W4ON/
kQpbkfHPb7Q4iXSBXjwXXBzPJeM70nbZ59Y64FWll0AbE8G6uxUhx0eRZW+0dkC8+HqLTKgHUSsX
AbO4q8A397XH84y1rlNjGIOAGdvDnlnyL0KoQ6ZqNmB7/iB2H91P2B5dwyhsHYXPfvXEMJjgt8YY
zSE6dwkgfBsaHqtcj3KpirFTTHLGsdK0Yd8doo/xKCT+cF8E5X7FlwDPBBXFh9vK7ElDCOkWh14n
ILvU/oye1yOcXyUwKcYod2gxb98mZGnqD5dW7Oyc4SrV5TpnJTZNNDDNvJQCGhLs2XSYGHPQy8EE
0QKZke7tHFmGDSJD2hWsvOenl912/ZSMTbg1T+tintpWEGjucyR6sQaxqj6wSeYT2nSPhkaE+O1n
eyX+1ge6ITv3hpvAhEvqYY8unGLaM38U/xdfbrn66gf4JtB+lIAYDF5SppTNwmGEnGMCnykxfVDu
bmOsnUerd0Mni0ydaUt7ES9FDE03qCh7GBTQhh0F2+p46C71H690zMmIC7HKEf7WfLuNqBJjLPIg
ExzrtUYctWFF4oN73mtu43Zd1/ypZG5F7hQ+/7ZJWoB/MuyAe7ONu88xEqQNh6SwcPnEhHMrP5aN
Qjhzx2rBKSiUg408YvqCReWpLM/cVQiKfzjG85Wlc+KwOqLwsXgYK+jQ4AOJUZB8quPtTmcgvB5+
MGtuRV3ZHno2zinE4+q4An+R0i2sVBO0IGXnjDoAN3FzudLfE4N5LmGPOvTzuwhwj0SN9UZGRS49
JdFHdjeD+yhXskW5aLjcdCyKY/qHFjBdu3hWaWMLpk5vX90aLtwzc57770d4JN/WZKMx27KRiJiB
uK95mp2trYCD7ObNtopL+yj9qCY+9DxXmAuzJSvRlwrMnB+2tqGD/DPgw9z88KfQ9QTJuslw4w+4
LrYDI+caCW/u2krQ0L4buDjudaYQ8pSB+YTTOIrvOhRux3WGoSzEFY7L+aUwdxW0w3PS84ZPM4AU
wOwQ4oBPUOSROtOz/8xTb3OPACkqU1Zx2ErQz9yRy9B86ljbVWOUHWjquNDJIlSr+djGgOIcDOx/
rcpUgaM0WfLcZXT69EKqF+xVFYZYgOlx6oBsur23k/ehPz6GW60ikAAfJyTtAfWNjcvdV/2cCjJh
teiTRv6XO1uVvOTSjbfbONe9unGpmsNn3lsCuxq4jImf+Yl3dPI+UYiM3b5TSgKtBGlvC5vCI1dE
ov/FJMgPzzGLyOjd31NRco6mpGLHIeIYP8ijZq0wxDnigmzw4uKbszKNWPujXsOqv218d1kGMvIQ
21hhwUEDm8uc2bVbUHE/ZeDdkBGle9JF2+2rKd5nAkXtaEZJqGrYflIvj79+TxigvQl+UTGj5aBY
f/xnZghMISkRlmktkG82ueRF99eIXddC4uMOy6TVG8oCG6MMqscER7Z8xHiRLm+8RaEj94DtM6z/
hIAkYysNRzBXAWRNjGhQm6oYQGBxG2F/ezVDpqvyE361QS4O5LKMlfMn10yB7U+eHBJN722niWCD
Z7lijftLNdMh3AWnqfkT8NeALlWVH+GbHulJPtGegSffOMntR1SJaAcsUawUK9nvivvUVBSdcKDL
AJF62DIDTabpWpqZMc+3sjJLMBQHwFxoLcR4rv1arm/zaopRGKWdyBhrbUe9UhAT5txR1RBZ69L1
BgPOzsezW5P2iZ06V7+cCwvC07sFo0ZZ96fWsZ7bqAwDkpRLC1+XEalW4tYZC7OLZnD5GGX/EQJa
FP8cufP+BlPddSQMaYYgKMKaIcBukUYm2EaHio+X7cBw1miXeA6BXgRPCwF6/p5B7ElN6Iflvc2X
ihnpHgbSpzs2RHaufTfsVSQAUS0aonbJ2tPDQy47wXyYQR/UtcrITpsOhf5dVDr4jnfoK+CCi7Db
JsNZp6TM3mTFBVa3MO09h/e6+DJ60OkPswVJZQiDtbE27tdu0mfElhzHP1UOVtbTZzqb3I8wDSjZ
d+VjsYHN3TjxAeJeIkUFfF282UBchj/EqGS/g1J8IP9g4JBh2Lioiz/GA4E5Pu2cDMSIQME/D6G1
JD6YyFFwjIPulkWqcJUc51dHHclHpNjP3d7jwkdDH3gVxD4BWiUVGaBhVp8P834GEp3fVCA+WT1h
nP6wnChOkHUiP2GY5PWeAW6yOFr4i7VZDivE2ERVikDhyhjz1MmJ1ne+vUi11OxsnALl/WEl/TEQ
6pOsLCz1JxD78sPyEcC7mVdLHbhytw+Po6ffCPq7GGXmof4oWje6aHCAwgA7rN6wATCDS8KMY3ew
TKaQbOX8k49fvz0e2R5M3Ivn5zOWJaNYGix9HwSm5QUyr7y+399KHVwfaGiuvxqqtBXkEPncsFVp
m1SW/lARPOlHLqcmjdiipCpn0NAwSlB2e6tlvb1f6Q02R5/DxmhiXo/ofK9UegIEclS7m7a8crZU
3hiTp2uJfiHYsnyHFHgXxWbn4AJ/kzDjOIMPJCL303Amm2k4qFeEQBW180sMdhh8wkB/eagjeJAa
oRtQqKRzTYuqeAW8m887yHQipbqKX5iYKOe0h6NHwlzu2fgtQFYVOPahY7Lz4aQ/hF/i1uMkWdm9
h3jRW/PPjezv2pZVQoeSjiSLlrC53HeNcouuRIqXMaOF6qP/zx53ww5pMQPuusQ9ZLt/JvitZB3A
fmloFwUbdGsItJWIhVcXLyqDQUqPlxWtrhu0nWsmBV09simK2qrWJHGDNGwl9bFZ/UYRSeZ2kn6B
GEse2wTfS1PFWsDCBEixB/7Qyp9a++hhfky3HZ3nsziaDaz3WrCpD7MRQhqmzYxOb7sMEQ57m9Xl
wlWjIfitNPqTC2rqnSFqPn7Cy2iAIJHnxevlQKhRfyTWS5hH/SYWu1CPs/Qsrn3YYELJ6ioflhQh
8WljE8sJzvXGOmsX+cbVjeBLAxp2v0BJQWeKqghPZvi4XtZg/h0JmbgSBO1cKVImV8JoK0fgrELi
XU0qpa4UmewKeO6FVumnWUtFL6DRTmNZeQKRX9U1UKt16dmTz8TmtrgkHL9quIYKigemAzzdn0P6
ndrdtVAwmYAMu5VSkAb1PkF8gQ9PNk3hwhkSPTlWOMYSpeep5Tnwsc5H0T21UDtbFIF3O9caVwjy
fJb49Nh+LF+Fv5KlEhDbWmh2qsDB8UtT5QDk0Er53JM3lxOEpm+IFxwXK16rI/3/3zV8bZuXbT+j
fTtgtoc/vpwrwrGrMJ41SdmvLFc7xUPIWMhhEB6pvqqmn2MBi9XjsLIAkfM2baukfLClIsBkKpvs
AYfdf2Y5+46lPJekxgAo2dzCCJl0BsAcVRb/5qSh5d4B78AwqE3TLReDgdTq8H/99iY7+t6+pji+
eUlLA5km9GtgoLGVofe06S78stnqYzqHsSjGaSoTX9GJK8WI7ALKGem18bjgGEMClLUJHmfTgiIS
irxC73U+9bZ7iHBGYwFDIWTqoltGj6csxmRpUVzNPOf6QwyCigj3OqhK0SJvqojn6oJ04vkZVenh
q4/GStOEEe+3qAC/bFB62bOu4Ersp05/8mE8cjtUzo/4YIetP09uE8xGqHp/KnR7diroNV8piqsk
by8apLyszft+CyT7/6zY00Pgdt9j9IAtjfN8Fu2XDoTjgwg/ljr20TEytsBuTM6akA8PVu59/1NJ
loFc5aE2k2OHE7NxcscCjWQDcxLMaB1zLu62Kh9ZIobftt0JYnk+kQa4oZMQusDt/DqRwXVheqjW
c/7wJN+Ivj2wkexbpAwCU+cq+PBcmUvkPQA/u/jbKp1EkSc/TVdng5oAWK/tPpgiwwOorQOLq61s
CGTp+rwMqEll8V1ChMFfcovl6tltC2kYYHynbKbo/InUWqJK6tQNehLS+imwKrBOo61SO87yHYaP
kpYEN5xhH64H0n4uIC2DiyRPp+94TixA5pzMPOHuVEXzNWSnWTB3KfmWffEgj4F5Lvrj+EEfbhmx
kuBP0gXlLPFHeO3ryT1cfrkxRxBwhtycbEeGrFi+cUg9e2N8xpFCMcBRXdC9wEYvZnhnBnBG1Nxe
S7M5diF45/+ivATH/qTDfTrAKJcEKp5R0HhjWygRsZOJ10PnIruWj8CtMnV+Qltq9ODBruQ2ijLu
/Vcwrh+gaPblVGes6bhJ4H4FCtHAmgqG+8jPP3LiCwL0wPk92/uzWtVr5ZrWarzu6WvefTmCCc4X
p60pqmv7QmIWUJO9YLxiIz60LzQ76j+IWi7esjz3WwEF9H3bR1W99MjbbXjLUT4P8Zj7PlcAZzZZ
m7m4Ym8tu5L6ldiSP3cM2zurV7dfNw+PJHDNL5Srnw3wfBJ+v6uE0piRANuTnjeqxgeeqhqKayxK
eQ4A16s1KRhrq+I2jELXDlFjpn94Pjp7yCufmbxTT95OT/bpBt44KplZBC2CG2hprzCuxMMx5gLW
Xb8vWsxvVaV52b+4+qv26s4Pn3hkVqMC/kNjatb1pp/cqOy1i6qc+v/jz6OxX4bw7J2W/sPbyWiu
4G1YtXUXfczJC6Nz9rMnN/wQ8Ak1gTQKU0tTHESitNwVrkMPZnnTPMkdRNYdultoKNMzBFxNH/Wp
WnLfOMbbtHCNDguIxro07B4Up7aH5OBC7OzcnjAVI7zGlN+OV2/toNo0FtvEH4hHPjdo4I/62z76
Fixbg+JGutbAGpXrsXWEkkkNliDzZ8hwdrkMaj4TRWamgYXt3oiik4IrIuMBq1plvexXzHV/6iKW
Y+1IeZxm1C/sj7d/fDEAAWulmv4lp50wFVvQ7+AUGc7aB0hapzN+ZycdEbsZb2wF9Ij/0FIKkOiV
ZJg1HEICxIizw1ixbcW5TjA7WeAtkYorhrENmMwKZFhZ0toC4xGMKXEOrK+R1H68wRRASkUqRXCl
Ab8IfXGX8mbvSoxUxeVBAhx/RohBR/sPpm2puL62H/AHTFCZfE/0CWqPsbgYgoTzXQl1nVCZvk6/
TA3u1Zel1dSPxwLPtI8FmSP1VaJzkaGTWjtmJf8W/VyiT8maopIaO+JcJqmQie2z4scaAaEdmeZR
uKt/pJUbMKV1xnMAJ/wuCEeXUSvGQpbbmBnQjkmaEeuliJBkDdhrHXVd0A7Atb6yp3yWjdEqv77f
Mr61hq5GveQdHq0XiHkITd1gANXYS65KUsUyQL53smFt3EFGuaJHRW6zccMr6J9XGaL6RI3GSmeP
MCSswjW5smBHgGSixdUa12joXrCpfcmFj8cKoLkmhWT2tckjKfM9Wmd11BoyO9m3xxd4LyEH5jDy
0bwxaTYU9TwlfLSEj0wZDr+KccyXPEpXvAB0GGARpP+jA7zQH9KL8o4PEyXaBOWoHjzz0+rR7/Y5
lg+j6NkdwUMRE+rBl+MZSg9bCvzGnTSO5/SC38owj8pFN4WuJYXh/e+X/bVOCH2b7RoPusxZhHD6
pbuutqS9hevTWoqzrte595jJEv8aGdw9zJPWbIDbo02iKwwZ6KpXJ+IGYkgkfOI4FGeL5CkCQU6b
mW/YV5ytpj0vGvHLHVNhJitBBzovaqXRmxJSFL11mQqQaAflGEVqeG4dJFnJF/NYEKmenw/aSusm
NSDqv+4GjMMSmdOSGyJ/FkwGUJj63KJOZyoyTIjIUQMqDQFj2Q8eTaL3BbQIC5pRNrAX885ZL13S
zPhXLIkoSvLDS/ysSgHx15qM3QO0EbUX7mNoVEsBpUiAjc/2AFRlAt8zWBy6nW0KNJgutJILt20i
azIs7xTbzzP8m0wS8VWJ1F7eGPLDQ0YveAjouI8e/byrEGeul+c+RYvW4AtiXdTAwYl/o8OOeNfS
kMPNGIdVr7CBkf9xa/ZrK9wwqrQyxXmbQgGvu95l3TgELEsVUdRWAw39/ZeDZsbEZtpXOtYihv9Z
SwiaZOQSOa1ZMOgunB2Oyp34D8cx5YfsgxcVYaeCU2NLxLgXqoYioE2plNcc5Z98Qb80NsAdqfeI
rbKUP/c3iJ/CzADLCYV2ZJGS3rXdBLT+pBx4ZrPVHF6XJQ0tHZ4qs5uWv8+8W+jSVTwAjsVOvu0F
ypJ+7FerXOdFbSHZOcAd4M55A765aBE9ZECKc73byqVBHAsWa31I6mGEXJ2JbRzg6DZeeDgYxMyZ
RP4Mt8zhy3lHHdqCZ5/8kSc9rBaqBVUNYk8QB6y9ERbEovVOVKssIucVksrtmXHpjEi2h/6+yjvl
9fX1VFD2ENHQkDCcjO2HEVUcRxe/M30coyj+DDHXDiqXsP3na7xnFtCBI5WIs01MCjt0t3sjirG1
TO69UvCCFsuTC8mCgv3YpLCDYcfrOwWhJRzc7falRnf5IBTudT/ayZ9fQqK8oRxfeRvwfr9GNXBB
fbKok40ce84CwNU/SXVM97Sp6s3o/K9O/7wuNGyF3VqoMLER/B6NYWHbivDCZ8Js8LbtxIB6tQG6
tM+sP6rViLQfirpZPwsFLBKHGXWBjcY1epsmQf10qf3/AA2WgNbMP8BXZROh1sd7nEojIRyU/wij
EV1nowm8+GSR91D74xaa3eWfbLMw8N2N9fDM4W7i6+01FREoH3OeUjYxHBojULzIWJMQq6zgW51K
ueABsO2pzc5xpB+X+xY5zLRBgRQ+9L7+8pvLH2cwaHu84lYr9hAUZyYZxuNnHCq9+2URkO5XHDS1
mDVJ41UmqzXJrZxUk9bbMNj1Pg2MryQYRRV2JPcnXNJJUe1L7ELmGC4ITIRRbWy2ZlmLldWbB1+p
/8L3bkjuk0IWXHd6xPzNMqLHoDdxVI3t59bdqTrKUQGjw/s8dF32+Tp50I0g/Z17q9RE2eufgkvc
AieYD33vj4syhDGS2+5oAV33hyNtXt/SQGI69jKoz1IMy+wAActARTOUQfYy9bccrNZHyUsVOCll
tscu5vzlzyebWLg7L1BuZia59o+eJhIKBo6HTKNjHw8W4I9J0ibIRm7WlOtmffhJPwixAY2EJOII
NuN+UhpIE5PFv0Jd5E6k/UubpDBwbAMHd22d6kMUihUDXiHJsnDT6jgr1CsgOt64pqqYgDXPZUjK
wDrv6oxLDOf74uNLx+0LxqqAzRsrzZI8ipWnzOsmR5LIbYAt4ukVZ4cNBw4P5eyDcnSnYTDqKVuo
Um3Mb8J1TtbrrOXAgVOzQBrfGSEiDZWmvOh3XOs/ZS9Ak+IyyoLISJT570fO/IiL+/BE0OOPVvhx
q8kc5NypZfy0Kxud7RxSt3+WOFjozbbZ4RQsdBiaE/US7/smvHMLYC3uMCEkBDFL5QfHWJZlFnSQ
W3dXYYKo5mz7AkXu+ADROTFzabdmrEYVoH/vK6bcZNpwaEroJcOAQNp+xcjH4HUnBVSEKsfpMK2H
1y0D8xaf69w17S35iXtLly1IbGfxVvOFa7wucH7myHw9BeX9VSkMmXlhdm7+3nAdCiwuaNOGOarm
tGDuZBx4sbSbIzAoumr51nIXnop4HSDnSLmQsz7yv2FDKJL94SDCSVNYqQRc/tersgrwQ7I4FVEY
S47FmgiZIDOG4fejh1INietLdkPjZf3L4jc0JF6p/0FG6hWt7hFzUQe4PRzsHm3rlr2RpFXURJzH
IA0XEH2gH811W9TMAC1agzkhXFydRRm23nbPkIZjXXoBWsomtM3nJv993bJIAgMsHHq2yQevsiab
KLxiM32D1QlSxKoq61F89YZcL3PX/mM8wacOlXpNi5jkNmo9enrSZv1z5b+N3OoO/7cNsDs9FYxL
/9ZC3a21Glek5c8GG4F/vvQaG9+9m+RH8nLsabYbJy5+bycReJaRx0+r0FYzAjekYp0tKjsbDZFm
eEd84KYkwD3YThHtbRYv02i/0s9q0dzi82WKzRccSEpKqZI8ccKVgKe9qlLr3BZW/+PpAcW4WJKN
j8pQA1D4Gxd52GgdnZ5SccK9kABOBykkxX3XQka1morJjLIkU+o1gj2jfMBsjJRHpP4Q8OjfmOat
KGWSM/fsgvEJrJKDHk6jq4YCoDRfOoTFXsneKd9b/yC8korUSRBJtM/8VE1kNexLogQHh2PafooA
OvYI8Ud7oMPmyuDkha1RQAuRANkDDGw3bKCekP/Z+4z/Ml1u+39IiUtGmE9pIyTHsDWqR+BaD2jR
ZGCt89M2xNjVh9PMXu1IhB81zs5YPFcxDj7cTd/yoW3IufgXlX3Ym8OWFJOhWe6L+GlHz6PGrpbN
2OdSMnBc9PG1PTIM8iqU56x4NvuJQLB47Gukk6j0krPA6FE8A/RmqAMTPNO6yNxT1mt82mRTC3Ub
BAEBhNtNPWEdNIVvlcSUzLfMR7BBShIWdFF59+N2pqrSloYNjrDMGm9LPkV+M4DOjvxbk+qVxVEW
sbx/HjIif6hZiwVzZgyZNA2OQrc7MoIeTKbymu0eKa0wgYE134OF7gVwcZOhrxfe1YpFLdbaHOPI
1QS+7EW0YaWV2ZwUB5Oipthibs1ke87RbL/NCPwLezgB6g68fRfQveMHC7RRqyXItBRM562P32W+
UzyoC7LJXxOo4che3g3+aEdemDatdxm22XeKoiVCFt3oqJE3c8lR4V41H119nE+1lt2Tea4WgtEd
6ldtK+ssZnFahur2hxvOpLFPyRhqTCL7pYXDCLKFIw4sY2m1/1m9Ztrh4B260tqqHxVtg/QDaJ4o
kZt/sIxWauXSVZCCyAsXOUDyDRraxDcwuqj05W3Ko0mAA4/fc8IwOplBZ2iDPO4+k8+662kz7MRC
tGqYUHBmWYFFwfK8KqdY6sIo9MaA65/VqS7cWUju3gChY2MyFn9Xc7bfX/8NBYFXwNDLtpRH4/hl
ZdLQvq2F55+2BsFPqtn0so/zv27MbLrU0Hdfgd0zxAyqiucP0uhFEUwpUSarS0IzFiQyJAJXRMbR
JMSpvy4tIsREtWfLX55LlNBwHuTJf9wB7tYgNUhSIm+CZS2qSL8Jb6I02T6SAPdS7FeoExo+TP1j
+kkCcmlqhRu5jz6FSV+N9Yg3qpGuldY87VHrUYDB4u9yt6jaseH1HM8wDFHPu0BufmbfVanyZU7+
+o9zpglQjjQmHT/WADmi7p1TOWJOjgwOTbQwFwBdlRZcazpMxitn//KwsKjV7jJ7mR/dN72/ZvrA
Dt4EWj+lKJZASC2LgXKE5UgYP0ELkLaB/L2P42f3rXwIz0TEOwo/ZuB+nA8MJTO9eDYqMZNW1X5J
w171WAsJ8vTlPX2dYpZq6wLy2uvxwlfqmcrxS8iLBJkFM2+y5Bx6NQu9kvOAmYMjEDikg3eOIfA9
OuvLphUWnCRYa2RthQytPld3OiENeWXwYyJhMU6C6MZ5uMNfObfKWGi3Bre7uZQGMoNrgxHMWpiH
W/v3hNacVOLMeTypLQbw5I5OmKjl48a/0XVpkXahYyg9WoqBGhURyrtar4GO0Cy8gQRb3OjvnBTA
ZicPNetTr5MRsF/7qC2uHdJya/3xRQzsQEW2N5/Tn1n359uczS5PoRiHJ/PfaujS1rkwMnDmG3Cn
3b+1RWXekSFuebtVj1Xf7mpdXjl7X5Wot5ujQz7y2JQ4vh+d84hb53urvCcF/xZakLG2VWEjOxNC
J/ez+oybOmsEqeVB1hpHCHXdIcmRjBPwH9U6XoGsC2YmRoNoAOtXr0buQ0Xc0q5NMSSjgpiwfEuK
JLadPgNWk20QEAG68M+exihtFI2yINV/hmrQG89d2ICPaGEEzSHXDbdKpq8jlblueKmEdEhUpWmZ
PQTcCv+fRBgfC9wpxngJXpWUAPqIhOOXWwu3K0Q6Bt2r+GjMmwPd5vVsg4T6TGtwOOl2AV87x8SH
DQrlc8aC6DoR/WdHTeMExL2cm1alJ44HhYBzil34t4IpwpArEbrTILdAlipgMA45BDv4pAeNqqh2
DxnJIOQ4EDSVgd1+bbcGvUFjiXTxH/qsIUKk8J97xx8wVYksBpX63t3yiaX6HxEBMh8iVmElbwvj
Ze3EZAbOC5pIsbui6rCheEAnbKmGuYp64KY7dhp4jOrCKmWGeXvtGfMsN1S/i/oGPvD7BWUurypU
PU8KZhG1Ks2ubK9AMeBTUZknl5eOAWjqKUnZr44B5oGtMbdH6FhRZDZQMymUP/ZvoJlBfOwUcr0F
o119E6tA92mwVwk6lMdWcvCNlmLOZiHotBS911gL5J4UWHvgJ38Sg0FCEZDNA/J0m/4jTbWr0DgG
S6YfJ4GveqdQCpYb3ahQNDtZ4ZuQW+XM/N+Mc5wrFLPO8nzn7Ui1hikgQKWRYgJ/pbjI85KVDOgA
+rPMaKZw7hFUor2cvpRujPidpmlEVX6p9sDkj5A6dc6HFeBXwZt4m/ZJR2ZUKveZYypOk95cDi/3
DFdv7/sFT5I8P+kCMa6K2IcLC2Ug2Rzwykv/XahvnRi0/mz45f/1uDtxAIZJGDDTwGiWALoqbpfy
8sTafu2AYUlPnBes/AIyCllDBOeYz6M8A4pdl8m33EgEvCiXM3UNaSdB/Z4MfbbLrQJnvxZDtESp
XLMu9e0MtgQfPwOCbr7ph1KHHf0eWse0D9OwJSz4+9+1M4DFSsO3/q/3/vsvW4JvEEHkgHD482Nw
Ck5kRq0AHjgcXFCApmxDT2QSTKtZoW0wB/Z5O5jhzF0u/74Ya+oKG2ypBHnkwPJlXhnIHM5IniaD
460dyPw3qwLIgzjataVXPA9IPrFI/ytRLav8Bxnsa0gln3SS3crTVp0i/2sMZDTueIDutI5aZxOu
H0EJS14LutqnDDRdqBiqSm/Sd7kk416lFPdlaTSmwJgE6UbAaF1SZu5O7dRp+HthxNOSoZeE6zP4
770N1LVag7eq80yluzoOYYjKPtQuqICiwdlasJgbclYLjjbU5BzRzadMXkz8T8lHrA72c2q4tTYZ
O6RWKC7wcmyBPjx/9Y1ICoI1G8KeAai9lX0HGnddEpZbe4hbLb9HIxlSXND05vv3uWYuzInbxwRs
px2x9bYZnCI0TpQJONt8GXPZpzoSYBpkkkiv29La19Eb2JYtHCBC3MpbLLG3DCYlo+VBpRt0x3fY
fgU8e14SspvCHoRLpM/mywpIVeTeKLxVv/VT+N2DJT0x8FWn66QMax2iKlQO82TFgpqEyOp4tQiq
D/QCmAO8KPUkU/BPG9hPEZVsyvSC+b2kn78ewKy5NEyeulY6ZNHJJp1wGjA8GS+NHM+OSbGYE+hV
yvteJ1vl4fCScpQimROt+qQhOgqTzwRDqDkOH32OEdtvsk8/dQMuew7WFzQnKCYS6QZdWeRVEWLf
lZgr8V/eT+ZQXTyArIASO38+kiiYiSvwDHI0ffQY1YcXWBCbNRO4CivWGsf8r9/8VnlvivEfHzRz
Jt9FVmihiCggWrOITjO53MzaTYoBEosrkoraUmvBHy++gVjJAfppLGoYODxE3OFZFO2sP1554UCu
lFhWtKuU8tuv9nLzMAciwB9r4cJNvzKARIGn3xcuS+KO75I4xyuJw6PTJrLEZgp9cCSLvt4cxhQ1
ty1aLcrmCr6rOr0Gjm1iUSgaKwdZB0ZgBF3HJ+zBConw53cbp8IpRJFDvRATpGscS71+odw/ShJh
qA6C1S3Ofks+p0mQflPv39MFPsUH3YzFXt3ddj/91cPURbEF+YUvUBuJ9p24Dfn5URHym5GxPU8z
xZOY6jvnVfUU/QDQ2stqrVY01/yn4AAycHFV5gQilzzlfJY9Ju48UARa1rm1ofWSzMwCIzJDwFAz
b9MLzbOsQUPpvhbVH6HobCcqTOZoho54H7lLehvc16rnCTGbHua/iWR1Tt2BJWL0QEc806GgvF4u
598GCYWGc9jYOalk5aR/7KCA9PtS3zi7XWu8Y+sBJhPrUAvI7QuCojvxa/T5GZ6KnFYlPM7PiyLw
dCktMq06Fjw8vGrR7UsMnm9Z9fJHHKy8sjM0bBmABdLlQCw5FWaxHJSz2goNch6yuBk8Mp42Q/tb
8ruujgnpOJAfhz5IX903Q7FCAgAFc1aUm7gVPyHGNylKwStRFh32KcSMePqmu4PtWtkhyrMWwF61
rA772ng8NTxeMq5jTUml9W2JOV7rnYhJsAxE4XsxnpKdIlecLj8DUvkNq8hkFMjRTTrMHxyt5syj
XCc/GXJhaNv+baWHvysSHAUEB//kOW499b8JNevZzNqPt8qOLRnAaVbjwzUi2ilKB6d9bRz0FL7J
qN4Wcyuk0dyVbvO3HtJbjJlyy3u+YIK1u0Gktu7PBH3T88ZNrrwe29durAwaSofvTHLFWDnPeeO7
qeP5v7pyu4kqy6yWu8MCUqc9QHbQou6vAfMTPKwyMV2vYZzhJj7J1tOzaAd3jCjonLMsD9dVc/9M
DgtPycYCzZLbmjdEwpw25DRckyjIiBv/fVdvR+3TccY+E/ZqMGjMn18cr9A8BKw3eQJNc3sZB0zM
hxYkqo6FOJ1sVagf88R1xWNx1Xe+oQcCO8K2ldT5ix5RrxC0trdrN8OO3qWeg9qA/qS+R9ZeMfmp
4JQ42rgoPJ79uJHOqA67BemeTd2tfNsZ6ek7hp9PiyrLRk83r82aFoRcihUf/E9ipCxMc6H/4WRI
wZ+oXTEYjILIblrQuFfZ2gpVOfCWL5gr6Nq6YIhLulgFXbOjsIfka9qNIY4FSuqGDFmKzIrRM1vN
J4+r4DYDBAHOnajM/9kMlm2UxwmMwfhk4Ty+sIdjtOod3E3KkX3/bN3xOt3OiY08pylaB9LM58DK
L9HvXn37FT6wZAdDhypP/ZMdeZqfNo4jPJqoopARcF8mwnNKmylgnH7iSZz1/9V5y9r/I2wtWNQx
DKrI2S63bGoO69sFgZ77mVyxUWT9de4pFkNrnR/5tm/YxTvet8Xtthsaq2M2ET/ccDIyHDF+fi/X
BUtPznizSO928Gb2oOWSZnLTBVXLfuYY1PY6TSckHEOK3QYc58UQRBK3sSTe40YhW71TJ551WCnB
g1U5mViVOul2Xr5YuGsjyhWJXIREZhfuznGDbG01hX06yuYNciVjBYLoLhVPBaBjOpt2Ji0B+0Xq
oMMopijDp1nTGhYvbsoZi1pbIyxSwDYmXfl8349FK6pxk4Lbx/zbG99EZ8fn4UEIPXfX0eJTvoq3
cNQU0FKVlsnrIt7f96tIU0+2NxZhunfQx5/6D4NcP24HdY4NOFTfe+loMF8bxMr02bhJQpk3rB1s
FXYj/N5M72KLCj1hYcYLVIGhaJYMUxJQ8znaRNdU7J52gq5+IUcfi8A8saVky5atXto26fIZJIi1
N8l3DyAFS2reydSsk22103f8RL7o702KPrCMuZskNfozDi7nRFDbMtzwVp3t5c21IljZlRjORFJo
L7dd+lsG3wbljZE+xgsq0n7+WedtYIgjgv6v7zdqx03Ga5eITqDxS9ovzLh3xVSx6rJpSNe4omPQ
Z5/2hv3Podywm3SD9TrYZiNETOAFT3N4ekM/bGFZinU/12Kl2atWMj8n+RjM0RBZ0ggEyup63UU1
UWpNldJEGll+QwxzEjcWZEBUIwaKOV622qAFrJf40/xl50Ik3/PBpLKjxO9Mh+UYH2K8C9lfTDNL
8dahp78Dms9wjipCFYLktwNsZcvupqmw5YOhKpR9AbdwBk5lNrI/ogsQitMwE54pgA308Mi7PwI7
xI1/FSx5f/aTC/2BSDMyoHbDKbe1ukbahKbtzLW+iIpNAMWRu5Mo/tZiInzI4djZpuQR9yeLbUlf
uJ2F60v2Qb7s+IIL967xCf1VSwlU2M2lIYiTAZdeiiJ++iulI7El+Tsfmha2z88uq2xOukGwLxwg
GzBfZ5BweEOX8SYhZ5W9kcR+8NdqF/Kj0AJGPk8wab+c7nkYP0m56QzoluM27aEUJjYofm33qQPL
7EmrM/y5Y4eSOw3/ZeW0BmTP2OjEHxF+GotCAcXoXFxteV6mNZ9Dq3cV5ev19Q2FrIpv+Aatj12f
sbARLfGFpaTvQKZZD0Indvstr+d/0hXv1KKMImL43fiF5cXTeSXJnRbklH0Ll/VqnYmZpOX2YnkX
CgbxG0iJdFhspYJWkzY2nk2JsyXGnyl4qXUYkCUAxCJO4CHpe0YQqBQFvf1ZBxShHJAojlf+kgzH
gF8Ld/+tKhStOgpI1dhx/2HAUCwKnYdrzLSflxk37U4Fse6jJh8iRQS+zr5KzNLIuI6vplHW6t8t
8IuDOjKFOVqSQr6/LYZRUX/uyvOGhzVncTJzwTq6bov6a1ym6JrV4wPi7DsPkNsZpBmqIZYohFPE
0+4IX6C82+wk/dB3JOllN3abd6c1Xed1yYGHLJdBdJw8fFMVP7zMJ7HnKUIyNNTDDKHtw/9wbLRB
wQJM1d+hZq8p6vOc4kKtWT5Ya3zKubdRg/yU5YQG9l9/sDQFc7Ji/Pr5ssWHJ2hQtoAJ5ww2+2Kf
0x8tsK5mhOPe6HgMe7HKkFZilnwKWU1FL85MxdG+xzn2RmIBSPbY1rE3k4OuEYIGgq6GnDzu6Xb6
VZ/9Rk+jMFUO1E32b7XE0YZycz1R5RoWo3K9wNmNPKIKFbC/X+oWgcGnbAIWeFZo5W8pnsQkvaVb
X/vHymP5qxSMh1R/7u4wclpD6PF4l9qhWa/R+sMyP5MNuQ1ZS7fVL3UMTMuHLUJ+apO7QmYdeqBk
hwU49yuRG4YBmGc7Q+Q9yPYI8z+Hysixg0Xcc2LdFRRLTeLZlId4VS8DCLkYhjtuYC9uu9ljck0r
9MrGPiDMStR5DEEuh1WdTCYLM96ABHAmJQa8ukSo6Z947l5bA0A/yBRbkNdMn/DJrr6Qvf4kogh1
MBUzA/dPkxZYYSZXmTZj+rtxInuB2H/uJAZHFuRIOdC2HqOTMHNfn/Oiprrgv79aTrdpTaxHbucf
w+mzE/VZCO6FWZFTziMVpR0aoWRXktrWsj9nGUsmbAwCWD1MpYtO5/5yzQj/PiWiCaZqQBan1+XF
aiIvR8tq40IztRwQoAmNMB7lQejlLElNNSa2PyFkHV6vcR6IfPwAkDEseJyoQx3EYm3oB4KHnMup
MgU0IFKfDCWbDIE63k4PinNT+hMyaYePuOG6PEuaYP1r8XPXM19DxpibkrzyURl2cA9SOjIB8L7m
Rr8GEogiMhXwW9v1L5ACXVnHgYT/uKpvqeTCvcpwNpFa9BQiAn/q+Pmt8fy8VKqAJd+Z9HrX4Kv2
2vG64BveCxD5zpv8BNbO4q/sqKFTnYVT0k2VHcCHrvHLIi8iEkI1r3/8EhsYuWN+5fO6tDscbqqX
3OB3U/h8ovJU/t4W40z5/oLz/a98CgufWMQdlsTOZ7eLioLKvreQKd2saA6SicaKxB4U5H1QXu//
cu0Qdfv+xndZOcw5pzefT9/T1kglmRHj9S2rCS9EHaEFltP3BwEelme585mpXJ2gkVKvFgvXbygW
Kg8WKauAYceVtUftjwsOcaug9at7eLah0WBA6InCL4fXLoC8ElqcqNovm48c7XHUupa9UUD8za8Q
RaF4sKLMG2+B03u8ruwgBJrH6A08b6OJGwmAHqmGd+AYmTIHwYgIMVBTth09k6GkGfu8mbMcpdzz
gM/tPRGolFvqx015WiqemKurjAZ4nvrOPMaPFIUDeuf6Jy52chPZMAo3HqNd6Hf7oByprvKCd6GB
x5rVRNU7g1wcizmt9uy1j53N3ZxUbRXRSnI+IB+5l2kH/fwo09SYsuk1TEoxTZx+hAnHr6tE894g
k3SA9geegf9qdLNzwzV84JtR8vn1tTzmmghJhx8a8GjQ4W1qVTDsMhKVT7YJr2tpezFGkKS0RkH9
+itVFPowa3h/4lujNiEbJPsAnuFvGREgikh6dQPwZITb0kduoqwnAnMuaj8CMivVU5HlFZWSi5Gq
kxKK95d6QmknFQUxeu2UTmZFDMbJ+bI3GaismTENHKtZfXv5QYDBYJA+xaSbtg89XTqn5wTneeyU
rfz7hpcv2I46cBO6CzbiN2TXMsvXEIyL8Oa8z0r+7kgvXeyMtwJpjV3dJASsHAhhcgke25PbE1Dx
M2Vta7x/Dd/VBPrbY4NJicuFsTvultieYrMkA1lH+6RdWLIC7HSpQyapmVTdszM0xrHatFgbWV1s
3qgOP60iOp1exRyJr/8dFvl93rnsE/J4J1bW424PM8lpyTNj4mmeaD+6BHFoqzZNG/vD+ffdGwa+
xaydy1HqAo2dfb6fzjJ8KsJ6+CouGczevFjdbX8kKjma9Q+ymdQDg2y1GhxPHsz2h3CrJUTQIuz/
R1usKL9PzbQyagFPmz+UGxKpqT9sfkYSoGCIHXMBCeICZsSKEGieAy9Pr6zUE7Yx1VRWcBc+oTub
2vpdpg1Lq8XKeSF5XOn/ywhMfM2KI+k2i6bCLOVBbK6Nk0FS1WffunFkKfsYXky8WPFz4SuXc+O2
IPtY7R/qd6MB6rduj3ljV2mSiEOV2+UUQvA6Zit3+GguBl2K/djYtE0b7w5r5hM+GuSeelR+W1Eh
ZHztSjOH6zRR0GoXLgE0KojKM2Lf2zTkssRX7jVaquKoWsqqPPFqBs4+DKrhzxQ/V8Js6qY4fB6G
TfX1c/1EiNKQyVKkgxO8vqAz0qRA0sHHKCeA6thPS6oRREHX8hzNlMkH9mj6uM/aRB9qVxgzOsnE
QdgWArTAnR3IFzLe61XZrrgwpsfLO2WMS/q4syoBYIYmJGZ1B5jzkfKUXAZAv7XHX0tl9h+20lMg
pXDzoVBjPyCzDrBuqZ/+hEfzmiwxyHHOJA9/K/2ByDrh/ptkCXjseoWoOAJ0Cq+TE4ccuD4cNNzw
ijPN/cVZcUHQUrxbdsrUYc3G4I+6VfD9JslBHVzhyv/FTr45pOfpMgfcV0kqoVBlOVGYMusglXwt
Bch/iAL9NT3p9C9qA1ibLdWdTlwTkepPmYI24mP0wKe2+Oo0lngsc3R9yG==