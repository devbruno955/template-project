<?php //00dd1
// *************************************************************************
// *                                                                       *
// * Tkstore - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *
// * Release Data: 03 de Mar�o 2012                                        *
// * Vers�o Vipclass*
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email e Msn: atendimento@sistemacomprascoletivas.com.br               *
// * Email: suportevipcom@gmail.com 					                   *
// * Website: http://www.tkstore.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n�o � um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran�a de  *
// * autentica��o por licen�a, uma v�z que voc� comprou apenas uma licen�a *
// * de uso para um dom�nio. Portanto, voc� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc� precisa para *
// * alterar, mudar c�digos, est� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom�nio,   *
// * nos envie um email informando o novo dom�nio.						   *
// * N�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica��o de um dom�nio n�o registrado com a sua identifica��o,     *
// * poderemos estar bloqueando a sua licen�a sem devolu��o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   *
// * Contato: MSN: atendimento@sistemacomprascoletivas.com.br  			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPvYv3yrN5VJYEdcQxXAJp1PrfoFWEXLhE86i8QzqUq36v35FykTCFXcGSM/w0x0K/PlrJord
arNrByocFRYT0gQW4ti0wdX9wuYtMK+XIpHJ880FzsV3TCdGFd+M/1NiHg1vXJSxw4ImXKuATOZO
osAgzFBObFBSnzbk7Ynm4nuDXr6NoLpn419AztslzYEYXH3t09BrMUThldFKbyiDKUNgT94YcVO3
I7+CVFsavnLwEtC6b0DQCUhgfcw7CBcdxpB4FwvpoKra+5stUv5u2kkmbTN1Vg1ObHGt8PgR6EYS
0s5OzKuXJsWoTeh52Yy4zxGujwmEeE55xI3lmRWPzSJYpoeGQdlOS/So/D897/5cZKMpv0zoXqOQ
krg240IfYKxhFqf87ZBh+5kZvAjS0+DqDrLm5Ohd8/GtWpO7OVCKFSB5p2ZeN4x2I62qA/Ygjrnz
tfQCDvRp94LBXwBVk/CtACL5QTa8asWKzMhUcDzMQLK9GBDsaXHGtEerIPmubtmN/3FOaEhP9wOf
fK4sAQpEPhL6inbxC2AXuzAw+3KQugRnNLD4Gfn174ikaJ2KAjwkuHfBUoWI1WcYSws/qkWgtaBT
OQfXNVM3UKWr37eUUH/RvG/IGdpfunoReEKtiMCSzC7dGw/wN1dTC1JLPlojVZJp5XG3roB3cQyo
bTPleo/89pglEMWSwTRwuU0w1l39JcDUIl347blQgEgPDtNq1hM4KimJOLj2c5/9UwbZW40IDshq
OU7GMp2jURlGJQ2aXrnUtKyOM7XhQAU02IxHzxXOGuuIMf4kMB9zmC9ho2GsWr7vvEFT+SDUdSKY
NMjDf1OrirgSVNTZroQEOr/JUALJ8xUVT/Y3aGtHIThR6cw2aMD1062+uv2Zjvxfb4sExek0cAuw
ZN5yEpYWsI8KCoSeSDUXTEIvZNzjR/F6xn0th47Qg3qFI/dE1QfaqTyuN52prs09hjeKkedzI/+x
ws/vBXmVkKGVO79cey6QHX25Tw63wDYGj+rYUpvpQs/E8692iWCup6Ygz0JeORbn1w1ACYBzoN6Y
wi7d5onHvNvOM+nf5ZfJP8ClDk5b5/hsGi8WLu/Ed+11apcV/dK3OXkahwVN3GYtOZzvY0dsl1/U
soyigpDOXjPSRTTFNuT+h2jUhtw+LjIHrReTMnH6BWuIHM/fPd5Ra+qbfPMUqvBbBzmJkXuFa4Up
rBqnOxsQ+VGec1gvbPt2yQXP47olcigY+g3dBcAvSo7Kah6n1uW0KRGouNPhERD+IXiV1g27YQ8K
5u55+1ZqZ8vlQnA3gGjGxRApImKSE5u3Iz52/qEw7afXkrsDzQLTnRYQeS6Ob/7Kb1TELz6+ToZW
VDlvQi4530cfMnjiWYnu9bra4Ps+LFBf9CGpIdg5tec8plZ+8wHxzcPGp+NUVLoHHIb76vIffby+
bPcZymkO8ekVlr+a8iMG7sYBm4qH6p85TikTZIMtkiLf3ky3ntmdGZeERALqbaWQth0AMJ+FGNV/
/0F1MgDb5YOPje2a84Uhj9Sb9fqpi5hh7I2Lm/jxmPgB5i/XsIOQve7n68Qus64vkvzjYjJi3XUo
pHkASCnnjHzOZ2m0FYhtckNvb7t5yl4DyJiKIKgUkzXmj9kmfOl7/TNLKIBVb1lyNmdhQCkrUIy1
TuyXQUdS64JY9GqAIrIaxHiMCOXMubs3RSSDGB0DtjegebPLQ4CFfKKRV2jRc+d/6RLBbFtQ2VAY
ZcI+hz1+3ZegjhskQ+nnUIB5xSW/W6jU+VI6D/xk7Q2qC0hFGp3frbs4SXI93U3vw22YCNOPVVjA
FtXqWRB7QdrgesSp+pVFp6WSq7pO2iM19iRK6xMQtno3dF+eUtbW/lJBbbNQq81aSqBfFMCdJkO3
TOekKTECk5btklzho4iVE9j7qecvgQhI2ZOM/+x7foUS+m2dJHpKwmmpG7CSam2rtNW3HaQfCOEq
3t2IWE7Kf6yGbudt11FAmNO6iGfNJqvs4jguriDcRnzpYlWG/Z9RjPL4r02vsrsTj1LpkuGnPpL1
8R2SGYEZWqTLJ0k2hn2pgh0wYsLZSm/FmY7PGFrWG6DFYvZsY6FLnRuO1s5ML+pgXNIk9J68C8sH
lw6UvSUoODcsrqifIbFqyyZqR3dh/WI21yo5ZOfCHmWtaNRcvfMgVz1bFsKX1gUOcI00NGMBkjcL
80peJYnbxUXv71i5ToJdByEYHSReFlTdNn6UJ+jT9VvuoyXcQhrmJS1TRS8gJ2djJPh35oIfgwlq
KX5sU2fi4jR4lsqxK+sgZNhiWr6jYqWM6M/HiHklgH3ayfGV6+udS8dLvO/dH3jwfFnTNi5DHzji
GCWL4AHkM0LOCHyYaPXeIGJRWtDDYKjGXvFPyea5WCiPMIIpo1qEF++aarfg9gFfY1ZSeMHeK/TP
kYEPd51gCShLE9r49284DGQHclDsy2gbjDvViVBeyb/m/geBqUPdc03y3Yo/dDzQHb340xicSMRa
wFH897w61AVJpMcz46l3jX1iqlMowmEuKS60rH/asZwGvAjwt5JJ8OsJopkhA93XQMmZbuxgwC3h
LBOBL1L1Eql1Upbwu4vZw4HpbyeVc2CGkqlqvtPf4QycmENFtrN4lgiXO/rpfWIUw/0zvLGsRmN2
D5gnWr/Sh5FVwt8P1ir6a00c/ouKQIU1/2s5VI7G4mj1t5clpqeHXKFBpj1W5XqScTnUa3feDEza
pz6vVgnLPZCYrwk0UqFeO+KolH+dSi58M2u9viTQzyTeSClWzld4JGiq2OlgffL0I/DXRJxYqFTU
MA0K2oJwdkXfl01rFGwSjyqTyhUeFqiJQ2ELDurGjBwmDAGPPDXzUw7wFhiAFmg1I/QNBgxrOz6j
c1iHYirY4gV4El7utqtFRkpO0w0V4dJWJidWX6lcsAk24kp2RGUqdKAsq0AnMBsYmpBof3RE51AV
7H61UorKh6ODzSc/2Vf63qlcA1DSQSqc3vgZArJ/VhBLTd4g4j48UEzoS85+sqr5TS9c0DVGUogi
XY2cZ8PaMHSYdPxal9WwxZ9dQL0xPjOkMtw5jpjoBSaGJLHM+5TWQ4DjPRxM4abYAPFBqlMFRPaF
cHxRqpBRb/XC+sDSpnTtWui8JJ7DNMPV0M6VinGv1M1BhCNx+dBifu2XR+F1kUs5uUD7/Uix43DR
gvvsqiCjCt+czjkI3eudkU6fstRatL+A/2eTb2Ufb0ObY7ljPf+lQsaJZMlT7bajgg/zOsM8BmQd
w2V6P6mItBHElb96C8R1gtSKRGLgDhTmQmnK3AxJ6QHyRhqSz8fKEJrOnHPj5+LPUTuzEy+g/9NK
bgbS8fd7xBfnMR9unZe+ttdJb898PPhGXvsN33e2QXfndxa2r7TyUadiAM21aM33deP2KPBZHMH7
w5BzKg082jtWDIcZCdmSsQEK7W8FngHjwNqohCZUBLuP1b5W+ef4bdyFEm0EBP0dXh4MhQXPd19A
NLBLIft/j4XRTMwPYGSLb3WODB4BTXZmVCa+04QGg1Q0Zm0rCZkAHGVoPmtkal5P9HhixI6g7Fyb
9YKR459Soe2XZXTV4KK8YSVdcVxb4N9ITnLAlh2LXRnvR88SuQ39741GW8rLdXmDmjACxnZUtBtg
0LaE7YxS8f35fh0eZ8Aha5dUxYUiVBA5nzcT5jx44jy/e/MJdvVFCOrJ5b19++5iNkp97fT22HsA
cNHTM5s7eaOAcGnE09j+OgMohuRdRGjgGa1RIJL3kujY8oB/7TRKf6UK+mR5qspO34OFnACCc2cy
i4WjOoOJxa5ekN0f3uAZeWKz5M0ULdcpQPg/QUnc6mQMZdMlqK4MJfZV8WSiRGkzOOMhjSI2WFRl
83aQZn2TMm+qX/xHAbAK0RtUYkYjWU+lBvbTnPi+4v5Ez1tSgkBrhfgi1tcWC3KtAs1psdLthCvb
mMuDVwq6Z5lZSdOgKgBVFJCpg+Qtm0d6NMpZiiBSkcqgGSJ98kyJA+meuFO/xjENSLteORHHeDlk
Ea9eAa/LLlSqtqySZoaUhvUVKaBP9U4LAQCBRJrzrniFtRf0w6aNeQ8/rbT/YpvptOTMOM5VlmI9
UQ86oqbmIJ3pfDNNkQbVNWbNY8mzm4va+aGdOfPVnhX9Ij0SmA+nt8L5JjCRIS/CBBuOIKK4vPA9
6mdEiuB9D0TxPaNjkFMH5VlslH1x63fx0WJRysi88jrsCXlL7bduYImcO4pGYgkwJZPcimzkLN7C
plJynNdd+A43IUYmTjwagCMwrcrj0AvAN90raO4QsAwhVgPmW1ad+ywqTFNCvFpYT20qpapC3Bqg
+Pr++hf9v/xFXheEtF7SbxsA44ZuPqiX0N0CIeQ8Q6pH53EAyk74V5nynoRHT0569noOAh/wDFmi
lj7fj7vSdDSWAejQjWXmWXSE/CVea3QcPxvY1KNGHdom4TCK2bnT/vTBdTs4bQvKGb0z0/LRuRa5
Ri8br5rStXoNPCYH+HGigj1jW8HkHomfNVaklFbqmi/g+rGmGkqiJPP63MTBnsl+d9/YoYo9nnKw
CbYzcXq962hvckBdpukU5PGkgHRoQfJ3GNhTTvMGynNl4KBiQnM+E3l1xG5muMm5H3ZtdQLdw0zu
j+yhDR5OVX3RMA9j6C6CzZV8QxPekXtryJcm6boWwYaRBpLgrmQ+c6tHweeUruI/XeXDykerStNm
ylexl/wA3KkJ1hANL+IwLCOLTCMadMCUn7xb8jc68Sgm6wCbEWgOUbLr5vM1y3fuWTHTwvpwEJww
leJ2uAB5iqHBfI5kqB9qlXCCv+XgqpXv2OFa+tlCed7mMiGMBQdU+gLAcoPCQC6aPSLOijsDTVMp
jRUc/WFQdMPX8fAwrueYQc0rhzZjxPQaz9n4ayGYMXxckHqFIzA9d3AT8M9ovkcbEwezNuPXdb2I
ps5i0DHZeiIX9B+zYW==