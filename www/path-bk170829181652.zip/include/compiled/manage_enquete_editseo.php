<?php //00e07
// *************************************************************************
// *                                                                       *
// * Tkstore - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *
// * Release Data: 25 de Janeiro 2012                                        *
// * Vers�o Vipstar                                                     *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email e Msn: atendimento@sistemacomprascoletivas.com.br               *
// * Email: suportevipcom@gmail.com 					                   *
// * Website: http://www.tkstore.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n�o � um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran�a de  *
// * autentica��o por licen�a, uma v�z que voc� comprou apenas uma licen�a *
// * de uso para um dom�nio. Portanto, voc� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc� precisa para *
// * alterar, mudar c�digos, est� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom�nio,   *
// * nos envie um email informando o novo dom�nio.						   *
// * N�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica��o de um dom�nio n�o registrado com a sua identifica��o,     *
// * poderemos estar bloqueando a sua licen�a sem devolu��o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   *
// * Contato: MSN: atendimento@sistemacomprascoletivas.com.br  			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPwSqqkQKaIR9TVn7nRysLV8KD+eXn9P27AkiDj30ct/zJTrCroMutzOrSwnEIHdLe9il8Gb+
Ptg94Fo+RuSjA21YcTmIKHEOdj1U3tOWP+WbxTS6gkV/iZ4Bvo8f3ifOcQgwLzY/6DBus0nY45Hu
TwLqc9CcLXs64qpYatSRJcEh6qInLqjobU9WfPN8K0H8xBT/zz/4Sy/6g6tr3U+X7wVz9XzLgbfq
+QIbjd74BwWDJu5Vi3TyHDpO5agsWrXXjnz0gGZiHDXXRsOCzsWeA990aZWkpU4O3FRsDot4zy8Y
r7pV5PWaGV9J+HjBjZULq6Q1JJsmGYfCqDG8UfDUFI8/aYqN7AwW7ufga1R/k5JlYZ+LIeCCI1I+
ARCLmNIfpq6zVmhi9ZA7Bs4fL/fNBTreKzpIjuWwB5fRoMVXYzhVA9aDn4qCXf1jrG06ALhgC3qO
5rAHcnkrANPglnraqxIyzcOKsvEB86V0HjNlmtXGAZ+6yXQH27FLsytJoaBLBs1KMCULyZWSQgZk
dXLcJ1rt4r9vxHzOmiMM9A8rISpyKrcKY30YO2dk68O4uHK5QO32e8AWyxKL3sK5tj/xGS3ncavF
HPLqU4828vVm+jbehX8FQyCiDFjw/0F/D5gTtoTCZ8e/ww54DhTuNbh7oK/xYYmvDkGND+aCvDoC
M457ZPTRm10tVTKWsZWb0Im6WM69eOy/t6q8pdpPg8fLjkMy4q0ZVnOBO6WRqnnEOogatpKNegIf
bmeLEi7yEzfMPLFn/DUBotlICD2nGJyG2HNRmKE6WV4uX0t/uVbD+7xd6PtraFs400U6tfn8PJRf
erjfKbAxKqmHwm73zk4SNFPppjp6jbYK8IrPgvDmlg7YNcnPbDOcsaHjr6HoGbZJMdUJBwG6Ya7x
qrHqDS+EkJaLmGFq4qFxHNeHueV3jtynyfzQsBWAbU/+ToFYtNPYKELyudxocYAompxBJn3bVVd6
kKjYLmNePXAYGrxGZmGfwUTVlPY5hEkzCF3g/gu3XytuMMmZwFoBFQT2DA58h/Xi02BKpV7bDUKp
eomfvvVf5AU0Jxrn4IKqMlAbvXZ1modtbfhTD+TQmBYTijwlclXNBfq/bf5VN2rsoD692BWbKXXS
A9lazEa6QIy9BFyl8Z58u2xttJWT/8uBLf9jI9WzAHXQdiy7kLwgMUlFxNuDBIbDotn2QLZn4d2+
ru7KoiBo4hBY72/FyozEOm3mLXVSxqb0US45RcyxEd2iUZaP6Z7hS5DD8BSYA5aBJE49KSVXN4Gz
LyCTlCcrlMKvBRATnMkJvHv/WVKaYKqP179+bvGRuyMquprjP4Zvig3HfRTYAOauKbh9oHl+ugns
GB/0rV/5rctxJK9KEB+g3bz7W3f0TRh9hdI+a/r0ZB9b8WgSqAqQhOsvayOeE5doc5WhqBYSMmNo
z3VMpi+jIPgmxJ431+bPvKsnLDNjEa4w/LxikWr2v3S3OoKrOgi4k9uCGmLDSEFjp0zvq0nPMw3b
64cq/GppRKS0vCRccL+OI8rIwS0J12j8l+CqpGBhE02bk0QCUWqWoDShuwYsl2XqBjQ2ZXmhBuMH
YtnNQG5kJW2Yxftt7uJAT24wOygKfaduB7cxNWtNczHC6u3W4yHOACMAvYAyjeUHa+6+DY8STbD2
hibfAnkoNbk0I/scWgTDgdhL941Qxy2H5ld5eBMvrme4ISYuwWE8Gk2pqt1tpSC0p7y+d+Abbl+I
ZeAkHGf3MytRdXwtQmR+vM347sXF6GLXpecoDLLHBnvQGL5OGuZdx1u+kI/WLoFcA82QJCPr3X0x
HQEwvewvUDpU3F7n3P/85fpiRrJkNaYHgCdavsOz/kMfIxQKC7ZIJ2Rxz8AjVn/rfvSTxr/L5goe
XoN3mYyXsXp4qGARWvib5pd2MgAJ3g6+Pqvl/HgRREeLrqWfQoyAV3JkBsQHdhqHxdGeK8M+6ezO
jqA3tMM5eHdzEm3wz7jS0TcfCNRVvm==