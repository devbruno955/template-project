<?php //00dd1
// *************************************************************************
// *                                                                       *
// * Tkstore - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *
// * Release Data: 03 de Mar�o 2012                                        *
// * Vers�o Vipclass*
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email e Msn: atendimento@sistemacomprascoletivas.com.br               *
// * Email: suportevipcom@gmail.com 					                   *
// * Website: http://www.tkstore.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n�o � um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran�a de  *
// * autentica��o por licen�a, uma v�z que voc� comprou apenas uma licen�a *
// * de uso para um dom�nio. Portanto, voc� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc� precisa para *
// * alterar, mudar c�digos, est� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom�nio,   *
// * nos envie um email informando o novo dom�nio.						   *
// * N�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica��o de um dom�nio n�o registrado com a sua identifica��o,     *
// * poderemos estar bloqueando a sua licen�a sem devolu��o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   *
// * Contato: MSN: atendimento@sistemacomprascoletivas.com.br  			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPseqlnn4hmDJ1VCgFnBl11WMwyEzLOEPwgEiwkJLEMnn6eT5+k49ylv0bhthKJRyDt9jol14
mM5AzB9oX5x/d06MmH4lMOu8gOe8X1OBkyjUB4jRYzOc6yLDmMRLQq2JIulxQI5OdultkpBqLXIM
4xW3wPWoZPvqjXqsqe3lsVmTbu3c8jpY6TERRBY2EvXboYbufTp2/BM0ur3PpA0KMbE85RQ/BFCR
wC+eXsqpcC99wo1ZlJwdCUhgfcw7CBcdxpB4FwvpoJvcl7IXG5HFnRL4JjNvVg1S/xDWECs/Q0BD
HiLJlgmxsT2tHApwT1WeZsfUINQZ3XI85ra/f78wN/TeXG7TuY3ej3WOhNG3O2tQx0i/8BOT8aqL
Mjs9BWxGYzhIAJla/xbn+37fyC5TYZ120ihG/kMJyUAyWHwZD3PLSLGNuTY4Djxb6ekxh5Vfk12g
kh+4MSBwZ8qt2uOmYt1v40lWNHeMMBK0cHMYlvbO446icDkiN1wFlW6leX81R0dH7ChNjNv05xil
rkHXeOBAl9YilGF63N0agRfnAEcn/mUKFp2yeK4fC+6H7qx2DbkdbBtKbHHYjUvLUc/10TFCW+84
utWSpinTbqEGCA7eUDwriNyiOryRBTxMmoYcxDHUDojSaJNSjSf+AyGEFoBm8+Zfdw9X9KLsj2Ii
Y5bLdyth2vqp4xHfPLWtLC89jx2ID9/hoLvVWTd/CEQ1z2Aznr7UGFHap+dW5KJhW4BCD93Qu6uu
2xFF8br985zWz4APl9UpjwZ+bxqFPVBurFFwZwXA8cYIw3Y+BjoYO0d3JjDmG7PeShnGhJfWp9IQ
jF9q2757Bg9SHZ3gKJlm7n9ygyGiai0qGwaFU7pq2pvtQTWid5NLKxzX5kS6VujBI3lOiE8EIwPP
/n6683Jy7/h1wVsuqSFGRJ/308rJ5SwQoFpvW6UV4dWwK0TvH0OrNc83TsSH8oTC4oTD/TEr8L+3
4xsoSrV6PaMUrs/G2oi3hdR5uMKg15XCsSqkZ36ksODi/KMD5HAUVt1mzOBFvcCuvCs4vrKPjIoS
DCja2cv+9Oq6Mg9TOp+IZR+sH69aMTIaLUYFDku7XKsQJyozqu7kLPyY77w+CtTVRkUX8f4znPgE
6rksYhH2VQwdXIYbeCe8Jwq0x8HDu6LcQxNwEznMIB/9OnijTBfczzHoGHJ2KyTfgU9In68okjIS
LevNtjJP+2JcRXzpvj/77Pk8QC/k0va2m9wZmYfMih+AOu2uturcyiRvrh9W08XCnhC4YdmtGqz5
YQgzUFxvwaOTlX1Z/0jRL4BvypZKJ2n/CmziYCb7GURzn7ErLAx6GxRPTSA658zjOHGpl/Xmqriq
xmcULljOVZrABwQY5dftvSQfx5LvJRmuavUdp6Jh0Iv5fxAA8PEkXmXsc/tWThnYxUI/oM8meS1G
09Q8ft7DoPHg2BqYb+zX9oCiSVbIngcZcoV9FMg+gCxUxxPshlL4UKr4EYy/VBFH2IKTOlY7VPRB
0+Pvfq+Reru1MH3oEqtHyQZ5v7vN3XbwjhRg5BgaTSUEZhOoYMijaD1p5PYMfO9HLF63Xe/PbV3w
WmzZweTSRl9iB4cyFVrzkpF+7X9Okq0ZzVMzbiiG8SmQH9Sd6OkAB7VKmpF1ZbEgjW4JlB0dVTkk
Y/PAGD9a2LPbbNf6HDtkNSODcvPKysqQFuJ5Ja7c63TJ+s2nGYO9Fgui/INwhCYIB06gviFYEdWY
ujEhtHQJpVGCFGKw+l/sg/BceZ4J7iP5gFd2Jcgrz82zlWlYXIEoKPGfQ9/7otL4owHANkMM34oP
R1fY1SwAcBxHOww9rwMXqqmOcHOuCnzG2RrBQ630l8+Aq8vexvoorQv0KM/otvaitl15VblcvrOb
S/FIfehWwFWnT8y0j9AxDhvKz64b4mCIUNuq9OnRYgYC2RJXVNGLTueETlvxWzHqKo+vTZ8A0h7p
OIg1NZV5iZhhrBHp/d3+vnwc8HwjYVQHFXKwAf2d9MLlWIntpK5211/bgtx33eL1eNU6dW78yRLW
lBMboQhywKbVi1mLDhNlXDq0t+qG7AcgDzOufr51SOsvV4rRazvM00gXvaeRmntGGNQc+BiXKYUA
pH+JopHYfXRmVuEUOF+8Jq2Uenisa8f2hEevVL2+yxoIWUuHlawOeikKx7vL0Q+BXwdFctRcGwgn
f26vPmAg2icCiAGvRXIuLz9zXzd9lir6HEWGYSwQL7z/9eXvurML+RsXuntnUQn4L5Er865zBAJT
ANyBC+ClmAGvL+CT2213KRwm2uX9vYIBimgcJ88/4oasl5kUrUFfrQMDB+FisFoI8XjPrvz1a96u
fIPjKtAd4gIUBtbu6cusS0T2+R0Bg17qWGp1XAIYPCR+VMBvSf+f69IYPerVhIQqGfG+eBXfzbMG
QXHPiTIBNneaRpyiDh/zFvRPELeRpMjTbbEOGT96v26Rw3V8Vapze+yDe9WAG4S8UTev9m88Ql9r
O2tqBFUvs5STMF913PMMVr6Ep8CFYTnWiCihJw9Sl6rzHKBGzsmsdVQVubAnhy5SRBGM1TnQqQR5
9s9dN9NoMBWPSdm3GSAeqtVHGkElm3QVVFks8nGX4/P1zFCaw9WC90yAqjM/qswmCLlx0qVxHQzs
xxNLOrRh7gNKbytht5ZYc7dfbQkUV/VA2pT5HGm8HzJ5LQwzE2k4JytId4xiMrR/ffS/ABAwDFev
/8CF44qnvpWUv0H8rvZGBgYCFWwUfSA/HTozwaQ7WC9suP8mAmrifxVoesfpiFN/9MEh/sjakZH0
dP7CpolgO/dRoFL0Qj5ORATyGg/HZ0EjPqSk0f/NZ3Jwkt4Rb+OSFkI6sCrlUPiVU9r2b8yRDQvq
Snbg+NU+DHDP6Zznm8inpAWgPeigIXFUpu4oBUEA6Wr+bN/qSDMzE305Hwd4Fcz9px9bkEI4bZAH
SM/YHMvXeD0bR9uNVi42zKgcQro7zgDZNc3Mj/hEgA99Nf4fBaL01Xw+Yxrrp53Qghk1fY0ThyPp
vuLtw4/PQbls3ha2mR0iqtbbJvHmMikNvpf7qAkXKXWtfy3TAgM2YZEcBLxOqIwa6//XW5R3UiRN
R3VUyF5bvWdMgq3QN43bo54lMvFckQmjRWox2DAduMpcc18hfzvIG0P+c3GmyP3ovmNzqjZLaRyj
4sBmmFjMl8kdZBYa3cyqep5uKf6sPJWt/43+sx9q3lW6FHqxyAtTwtJQffuxyh5NiHqwhaO9ZuH9
NVbiVQZtED4WfHFczttlyWI6qM+d+68rMYcrBow9kny9Uk8GMUxnIV8He0VLZzv9khwfsimVRI0N
VK38c7u1nfyFHy8LoFAh+fQnzkNbMiPP/tclvFBW91yeJeI95eca20oiLdRRH+et9HSkc14n/nt2
i9ZYvt12RDG/9Y4S1lK1zIc/e+nHdB1C6RZnn2LGf2kMZtHB/fMfOoIWzn1KN1pmjE8BvVH5mP6R
4fqTBSUgj1DtBefF3iAaNUfrM68IYH4xJcYY9axPJyMeLXD37MSMnnTNDlOJsazFClzsRS0ap2oI
RjwrjzM1CExUr/UE79wBiGtGRKJevjtDcMFm9JxyB3cTK7zzbNT7XQpOm/RHVfpclWxAeOn9VYVf
A6bBoQS+NAvg23fDytFVjrUROAs8eoOHTudO1JxDaSe71+G4TfE9wtXXqdtxb++s0ZXhksXCuBeC
O60HOI1qfWrW8ERI7vP4TTye0d8UgjP6ZIjuS2H57X2JfbbDQyX3Rag+yIqLKjUYn2pTI6EsnWiQ
5aRPzQZgWgqdePgEs5UdlqvxKznH4nory14Q6Frmmnk0OCRE26MuS3TaaESjvGwADZXhjktd4+7K
LGxXulSZWaVtQf/WmVdZzS0KGLh38uMBtd5za6299hpEYvTFXiMvZxZ2Ct0AEiyUYDiRVoH2+4U9
v6n7dA1y5klYE+CjD3tMI/rPWwoiVgbb9qZEtnTxBoFC3zxskxT/KfcIdkDvv+zrpdY2HOZpel/p
ZTnyQrLFmPfXnZGtntYyIcpUwj1IBdqDJC5XFsp5jV2ba6bB7qLFHuCBc5lEGl/I75en6bJ9Jqx1
Fodztk2SJOVtC81g27t/dw6mICx3jTIfa3JrxAmVKvsc6swPYQi9o15E4f+bDjK3sxfhuKu5GTnS
5Xm0voQ/ljJxrrxk1fC7TKNoD55ac6og2Yo4MiWio+eE019nUpZLwA7N2l2treH53Mjk+rEuADY9
M2u5ZWdrjYhtZVb64ykHQq/osiEeSGx/Lrf+hhMFr6tqXG7RigI2LnPAhpQl4x31+n0u/YOXAKS9
JINfvV3mo3k3WsGiVK3sKX+kSKxRiFXy6/tUXwADCA63dR6tJwWcxgUi+PgEgmDhmXf+vPq3EEHr
Sby3cDVDzvMeA26NlPUp90ve5Z41bVmWsRilAKbW3m40gkwIrPVoAzJqiEHTdU6IC5QJsz/Pnyb9
QC9xGBCSQW8r+SqHZ8cAwPTxagjwGIvTNG9ALh+cTkgdAXOpdlcm4aFDpB2GMyQY9GOfEWtiyqbo
LmF9HDdSLowlNGzKrYryaZliqPuVPMUhyYqlhGdksVfsPLtCNAn1nwUnu9O57XbcEil3xQxIHhV0
U4+AzgVzk5G1Wj/Fki7j12aQVNstRIyj9FBUpdzNW/M3fuM0zvO=