<?php //00e07
// *************************************************************************
// *                                                                       *
// * Tkstore - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *
// * Release Data: 25 de Janeiro 2012                                        *
// * Vers�o Vipstar                                                     *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email e Msn: atendimento@sistemacomprascoletivas.com.br               *
// * Email: suportevipcom@gmail.com 					                   *
// * Website: http://www.tkstore.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n�o � um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran�a de  *
// * autentica��o por licen�a, uma v�z que voc� comprou apenas uma licen�a *
// * de uso para um dom�nio. Portanto, voc� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc� precisa para *
// * alterar, mudar c�digos, est� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom�nio,   *
// * nos envie um email informando o novo dom�nio.						   *
// * N�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica��o de um dom�nio n�o registrado com a sua identifica��o,     *
// * poderemos estar bloqueando a sua licen�a sem devolu��o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   *
// * Contato: MSN: atendimento@sistemacomprascoletivas.com.br  			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPxlChDNSWHKQZGqvzX3x8eCPAonUojXfyfsi32ff+XfBxkBmlNcD9648nQ/mK3k/phLvGCB6
zEMO4XWz8MEoRzPGKBDBSSV01A0I2w32y+RjDvWMHFUxlzg+8MeZYYPvTD0PrYuj5cdn95vnXMwN
jt6LyGMgCOJ9zqyS4EWJizdVy0uo1hvK7O4QR2XjC47eHE4PUAa/L2Fb2unlRKoHrqd2h/pAYzMS
QLcEHHRtDtFRzblXm954HDpO5agsWrXXjnz0gGZiHE5XFdNab+cwbHBWcpWsqDrH/wP4G3ai1Che
vz7YYP95cAmvPxLuskzk1BZYrc58EUuQZGXa+n8uALb8yn/fdfhuSk20HUvHUQlnZ6C8W65UUWA/
p1pE82IuidnqXXZdg9O95WMb7WI+9LgOFOQJN3vis/7Yo6TKGpaF04mFYy+4WjSxB1jEDnVrN+3w
4iYYuQZ2IIIBcWLLTFwBv6dSt7R4Luexsv8MMH/AZgHJxLcLt9h4bgTa7gAka4E62abxc/XV05ba
Y8aW07lGnB6s/TSKLx/za+wwsxD9WtNit0fugDuYkdK0Fgs3NtqTDa1rZVcGJuVPHSlVb1826z8q
MVazuAWvx8tETe9x908LgaOTls8BWKUeAelM59loGqk29WCI9HjLV79ztPKG09k65/W2Wez+WrLv
u9jUT0WmUgWTZdV6fYdJbmnv7wXt2jSiMt1msWWPofoiyrPRFZwJtY2PsAEqwM0tdbwXuMgDrdJp
1fkoU3O7xEzJV+bSaS/9iR374mdPNyNdlHjNr9EcSP+AudOS5iGky2nAz0V5TuiThpGVOrexRODp
uMt3JATHHTs/Xc08vtlelV8M+bO6KeMHx8inNtq4YkbH2s+QvUo/Pclzh3VWBGxP5lOciBOIrK8g
G3LnevTAj/z90eZ8h1luakofwNCCHMfWMLyJUN6uvGaqvM73Hze8SsvXhydSeSUwkbXFHqtSKV+J
VgK9kScb1HFlA0g5+T9zedtV2N47wjZBstdiKrXk/A6U7ewh3N70QIFD5z7Q3k0mmDE0i+C0r58p
86xfcq5Cj18xb/BsHtJstlwfnOsw82CK6YEu02nsDAoyXcc6EUhaKptPVCEolMmKSpPObJ5GM5xr
e9m0UahMrQXKHvftmPP9V41PpdJsxA9WJyvhHLYeoh1xXENTuW1UdPnlr0j9fmZthVHeZ7nz15Ml
/+M7JP0mFUGjHF4ihU5JqLLFPnfx3E2LXmo/hRHSio6vbpxMocLt+sRU2w2ObQNXe6hRL98cdjlV
Z59PAHH6+xLP6cbvih2J2zp6BtDInGKTrF8qPDpJo+50WNcAxWffUd0dnkGCmKSGcNPpVyuReRl5
bHVP/o6vlKn8IqAclRuTu58XEhu2Tq6zkjm+9Y7HbP6mK5NGK3Z2bsV5/gLllM6UpK5yxM968uN8
U47HDTXCT9jUDmMFwTAK7cIQaLf4KUV3mLRFigQTLt8BtUu3+2Cl8Qdxcbrhp9xVmm3va4ODD1O0
k91h0kDsWTo6IBpScRKiARzIEF7y4o6bVV4YBAeYyTpMsIoMItggadyI7rFbdya/8P9CeLu554SG
VX6riw1zQ5EfcoSLYBjCs99febCuDylPu+NBl9Rk2pXaRUhGAstbuH4kIkJRGOMFu3Iy/AmHNU+I
xaZ/0CMtsauU8bU07Z97xRLN4xwQESGf/AScXqpKkwfDBouC/dYsdZGOsXa6yVyqBfNgfTpWCCDY
TI3p9TFnoIpFVzq5gPrWp5nomhAnoTVSRt7SJgR4qmeDXFEGdCvKRtVqGC5sXGZQSHYIk/eppWOJ
8VImm53Ei11X5rRioc4Cru0P2gWVFuX3EOiuxFF5dhdrGF9YlGvmlBBeG3A3Z4713Xzoa6M5QKTo
lQuhw2XKOULHN9o9a5jXrRExFml4beJBdq1jMKsl7mSSHOe0OObr0bYKnAOQklR+UDk5z1afL8YD
kMHj99onWfbR9Mi/W1483VjDK1u8L7ipa6U64APjPvi1r327jg/6lbZNO50xjv6OyoLTPbQ+Kv4J
ngXdwxkGlUb04SXGdy8m+ukSDt3DUgEN9gCmcU2eUJEENOAdL4Tv5PeTP42Iy4mhb1QgMqaswepn
t++K3Jr1qlIWqIpAveAt7BroB4fgRHPL75j7BAoYM1q4g/XZ8dX61ddxfT6M9kFZty7CB8DWVcLc
kVgFv7HIA2GTcn+wcZlwnOVPKMFGDw3er1wJ2m3tlAysVD9xcVnKuZgv7auQIjxBPQOB/4Ir620H
kiVQdEt0odSHV8iBXxieiw0PYUx5wREA+Sc2RbDKnVBPxhf8hX3ZVVxsv3472Q7HmL+bYXJ4kmwK
vXMYSdbmMnA8TOr4arKX0K2/3GTgvxbSALy7ayXctOFxQDjhBcyPVMYK8eJYHZvl27+d6XiZ37db
Xk/8ucte2rX8P8W1ZhIv/PvX0hMK2ynruPk7bNwQm71cEdbcicB74+MG729LNDaNJMNCO6C4ubC0
ZlvTyzQdkpFrzx9ZFpEz3KqSHTyL448rR9imS0XzMOgU53jXOB2FO3T8izqWsTXAcwVOaYRtCWEd
DHYsm+knIhLU5z6lmqiFau8M44rNCcW6sTlNVq0K999aM623myA088P2fxgsfXATw7YNScjK54CM
eOomAtrRhAZdlTQfRtRHzBeA3NMlp7RAK8xuuIcK0kBPWr+jfucpnHzXBYlhBiqQLiGN4Ut8+xZy
0veLryM916u5uXIVze+wSeNEh1AdS57NHq7jutfbBdGJLx05PCh/aI2JPSQLYqIu2ecFz4/QlIEv
ufbnUWQD4VK/0pIpIQnFsBOQYw3KCUBOWf+MS48LdDmrGYzpy77yXjFgZPAN4rxArOR3rQx2H+rg
8m2qg+2ixi1Wt5ReG1jJs2BYm8iYDU8wwhdKJ/6blIBWSFjJG4oGSMHQRbX/FM7xmGzf556EHZtG
1yeoE0lDrwDP6SxuWphwquelX3vxYd+G3hTMnzQemgm6wnNdfzUJBT7wL6DFdbC4DEEI29sjzjrF
kUXYgveVhYWRCUkXVyXwHWLh8P9G6da3ReDUmZE9TMEnB3R2K8go4ADJX7m9YoK4uHQnl43tv3Zt
0zp7knzqKbwrKFuTI6PfQSJsksLoy+rsdToOtRSYGbEj3AwUZj6vs4OkW/FOeAeo3HLp6UnATs/s
2v5YPSrD0DKxitVxoZ9jikM7Q5Roi4ZrNA7AsqK8cXs6GmaaFcYJDmvstsgWiw1ImcnUmO7xTWVK
0WAawuDMbjKlP4KGUEINft7zzw5aAfw2Gsw9Msb5+Z9qZaM7fX6TEWduuzB0mvbVOBFxsu6+NY1V
NOxhVonIRDu3cz5d/+rm7BxzmPwk/vUbTubvKuZmNFk/eEqC38iBrFkpyIAEAxgNth2z6J8+P1+Y
lp2dv7dGtgDRtPDdIeWoNGpV9GlryfU/DQ4u9w22pyQIDJvDnPbBZJB8pGuA60g/f2GcTtCfDTQA
9pyJTG0tHXSgsipUotBMMzmn2ZT0h/Cbg1hTkyAq+N6wC+z1aXtJ3DoUHoqpvuKkNs2jMpZsdNcr
cMemhlNGuuI7nCkbqjLbkb4sbiboBVFkNCMvh+Mv3BE1xM9U81KHZV8wBc+SVIVvjrzueIErrAEt
iHQuu14dwSUahrKRjgeK2W6mQrutEYDlgjmNciAYOGwQYK0te1i/BTWr7zW4LD72TmMEhaf9FZPm
i5yTTKDhi8Yv7+VsiCT0kd5SJb8sIXPsSTQfA1Y0q1a3xG+4i76bTl5zaxgTNZc91P/peJy9Rfg0
l6K6Qb7IJEKZHV6bODOhtCTxuLQOK5HI79u+0c3ukIw2erhwr4GFql7D0CkqUpOW79tHpQfoMDO6
6GB7IY3LL48m3RsTE+fVaL2hpaYBoMBtsh6yWhL3boPOXrY8KQSL6s0PkGutZfU6KbbtduLsZqXI
SN0BgPyXaXyIx+tUGfZU0VgTQGsWQIPFhYT4yvoHsOj4tEV4UjacyHnriaYpRrx0eT90mBda0VtY
Zz0/k9uLhKsjq3toyCslzuY2BKqkPysMyWbtDE/WACBQUG3dZgFhhgi962TW8FqHJY3WrhdxRqNV
agaJ25zS8mNi10S96lyfZfuX4tuIOpJIiWAhX735ZqVT6310x/jWrgH+S+ZSH46LDYHJm8g2Jk9I
g8y4b8Hhkz5JVAVIcLFlqmlNvcCIuqXF1MgoSCEdvIJMK0+wVOFQAeci4oQQsrWesksDe8/W99Xu
6cG32t3oUaHEwF5geY4o9oKpazzqJ3UVg8x79qMK/R6t6A1+f6WuWjHQ0DpgBoazGLer1R/gCE5/
XLEMgHdCOPmReAPARviZdtcsi+rQA9FFK3ConL7+7xr6/7syAlnxk4XFaUHzLv9ms/x3WbVllgJn
Kl+AYlf3gdHjZI577YQgQoZYHidVOzbaLeVmpCmZYzwB527fmu6lpnqM/pgxv4GZ9b2n7DycXqe7
JuzPZByX4HZyJ7kV7DjtZzShfC7V6gom29ZTQe7ZlJcwlFp3kP6U09jIu7D/F+7y2slEnkSu7oQ9
1yZNOFEiyGAHZ0s3QwBErj/ZXnt6ZsjPliVj1cydnHVIlK2wL8u174koOT/NVrKJ6t8MOMsX6a+R
qU1kzgqRnTASNfvEKwit/eF2J/gft/UAasjpumWB0RfEb82rdJ7dbcHRPLlt9OOtkMDQTSon/pz0
fmaVr1WfK5dqLkMr6z3sKVsshyLxNAAJWciD0VdjV8zh3DF/7D3B2Z7HfNXVW95orYS31oly1Uzg
NpfwDZ+8C8QJBEbRP2F/gP9bZLuNJW5bYSQwAVIBjzEyHTLYcubekNgUS4avV4RGAzIrM7zKkcMG
AAejgebcXtmQBdjDTQ5CFVA9xh7XHlyMY9O+KWn1odH0nVfmedhoXdpj1UA1GSt8QO7J/mB0BRH+
aSkyZ/KcZZ/BCZyDPg7IhlPjnY1fEJTPIjE7TuWfJY0JybAvSQ3UgT6iFKjNfZL1Ujge1UKx9lrn
fK4NvDhoJsxqMLecq1qjh9QwiSUulRg/hScryFDNOcCiWlZDH4KjIn6kU6xMkoiK7XCkWQ87UqqL
p740Vj2zMZ0N7vvj2lILAa9AXpcBgn6udbTNZGLonz1nMFGdcjQFzaukTWwTGfUoRCgifJtplsKF
/vRY62wbPg5R7m4Qp4hrmbTHSmz1/Qvfd6sEbIav8Rqb740wYX2Kpy5hRzknSShJrCuscDTlNBGB
GBtzj2yP9HILpHzyga40Ws1OkMELw4CuOB9Uq3Nkkr+K83i0CwSfHJZL1uLoktIw2xA4hp/6KJk4
MKu0ppV98VgmGDycYJ5w6xKYEPHWyE+mhlvIktAaqnnOeX1bFVm=