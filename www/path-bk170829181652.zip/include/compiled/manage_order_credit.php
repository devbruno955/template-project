<?php //00dd1
// *************************************************************************
// *                                                                       *
// * Tkstore - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *
// * Release Data: 03 de Mar�o 2012                                        *
// * Vers�o Vipclass*
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email e Msn: atendimento@sistemacomprascoletivas.com.br               *
// * Email: suportevipcom@gmail.com 					                   *
// * Website: http://www.tkstore.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n�o � um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran�a de  *
// * autentica��o por licen�a, uma v�z que voc� comprou apenas uma licen�a *
// * de uso para um dom�nio. Portanto, voc� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc� precisa para *
// * alterar, mudar c�digos, est� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom�nio,   *
// * nos envie um email informando o novo dom�nio.						   *
// * N�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica��o de um dom�nio n�o registrado com a sua identifica��o,     *
// * poderemos estar bloqueando a sua licen�a sem devolu��o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   *
// * Contato: MSN: atendimento@sistemacomprascoletivas.com.br  			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPosIrsMFI2nAGbL2HcihinPU5xbRX97XW/KWDEChlo8vf7qvI3HmDmaBk7DRYXEPaxZsr1iH
bAowwUVAMo0/1pCTffQfL9wBNQzV9yiSipN8g8J8MrBebAA/6ntaGB7s9B9i5d9QEIS4PfVaArYS
ZiT7jf4dYpNh6oxvLVEGf+10i4Mr5cMAT9AtpUKzV00FiSw7bga0c7+LBwlo0/J1CyEEhM0c3QpE
Dgzt+4uLjAokOSC8fGrX5k0nwkgcReSmkQVlCiG/hdF9U5+zovwyas4vuAN/rJc9cNN/g6vvOdD7
nApQ7qIsNJ+/S9P2v604+a5JxVc2yamde4jYrM/Smsz6BvkwJ63Wjxe8VQ9PgErab91ozyTAIl15
r6uAdmh8l4gZGJ6QxwlfHaAvo0fV2E5030gniYBMufLaMqPtdmKxMlmUosFkfQouqQEV0OLWSWdw
FaOFluvgrlDBU8jJe2Y4oQXO18paa2KS6syhwbCs2mlmROAsDqrmKFhB/CpZcXJ0bx30QRIcfA50
GCLp8G/AIc4bXDxDoYM7UV0ohl2GT/GQNUw/ZxNzOqtKOeQIghU5AjgEN/BjRSIkdjp6IfgSu7Zm
BwmnUj17L2dxwvbkqh80CJlUL4bi7V/5TpFFdNKjXuCeJurn0x5cvrp87jKHq5SkVHh8DZ5XiFLV
n0oUkZG7wRn4UrB/ayckygNMyjA//ryMd0nD6jwpm/KByQGYEfrzaW9s+Qs0IAt2nqORC05Tj0V5
JqJgz8ZE/Qu63rRJbtSB0o8x0KSwrde7SsUMNlAfOg7Jh+XVJVqncMzK0CHTji35GXw7j3tSPd64
JdC5UP0Qdido48eBOGU7xBaiPLAG1QwNcBzlMo1QOGffZX2aWux0Rn744yFxsQfTZITLGr/17tli
dJA5TqFwgPWEgYBYPV7wZVJuHFx9KMrSXHjBsReKXWZ9qXJm3wKNfIaLEJLWSl1f4AH3nwnG3xs3
hvDjbK+mvUrNf2ki6R8Et1gY/8Ey3SuErKQ6U5RwbkIsUzv09ZwCis+dQ2MnYWO8gx9ni2ASst/M
1SPTJeVsylVwaFS0VC4ulhCti3s32JcPob2mJJsuqk7ksV54/czw02eMHpBp9xtYw8jzQcHjKzOT
u5qjpCwrv6DTnYFG+YjKdLEMNUo0QMoME3dq7qSA1EHuEYfkO4ie2JsANpamj9mO+A7d1LGlPENk
UjH/q+Y7OpYg3KbDErXvcQIJSCbjWH23DpOtUgOPt+ewKIvD41Tx31Vm7zMg65gyWtLwtdFPTwNR
+YWZqmUlrLzhXjuT0okKmycoch5WqH/+q1t/aXK0PsdKyGQ25+udL4xnd61HPHJIp5YVdrFBj/l2
ZPyi/J0Sm8oaZud9ZN9KW8yEPmyndj16qILB2LgB10W5daTrEJItYos31Jq6K5rAJjXnoPpy5teB
7OYIvTLQuSZTrdHaFnZOdz8ObYEvuZ6lNmAZdqRSfNwYMcPQ/P5BBsTleVbovoIANkziU584fBdJ
7UzkR2gRuE52ZYCTO8zLfB5wyjqSAIwX33CPg8ND7xKij7NI6WQOnbk1NsF5hlv+RAiXGZ1MlRcb
JCQOLQDhcONLkrcbEdZIdg9MIlUa1juREJXszNDLjh7+dr8a8FaJDgMhDUzLTG+xJQtGdLT6I5Ez
pANsRJ7BC0CZaLlYZi4wJfn1zL9LhmtmOLoB4tXF8trodsB8v/tc6CLXXkvl5T7j7wauaoLHXCMW
fkI8ClpJHRgOR0P3RvxwXIQd2l5c1yFF/OXrFwiDm1TV5jApPR7eXvl2FZdkuHnHjStV8Lyff6L8
85Aut9Jpb+CwIOiU7d0ldiyQYdhS+AmcVLkjQc51TBuS1zZWvJEGlY8xSrkv1/TigbEu59L7rcBn
XDhnOG7drTq8Ws9rc/BAujUKg+L6CWDrJz8F/pAU9cG2iDwhVYy/BCv+n5PGxyi323YaB2u6/Pls
D2hlWRaM9PHN2DEAblvE55+QKIUICB/ORWY9n8SVZDngYCdaPEv/HdyLxmtYzNomS4sq3MV//rvd
BtIRtfKA+wWXXHN5UlYqWnjV2FkKv2ZjCSh0AvEtRx2PZ9oEGHsxbWs3cT5WXj82PPCnlhxDhgGA
oZQfGmgukCE/oCAHl09WMs/ffRMkrHMHw/aWo4Fs4QWq65E3g9GNBjEwjC0EO07T5A2r2arqc5eS
duXYSca4jqw7T7cZzj1YINhNRdkWoNEms26k51WucIBus0y0S+vbU6aLxJ9v5Y5fQr2PddTpRqvr
a6dKt1CqHkTsNNfozQG3OGOqIKIIc4YgagpHTE9hSFKJP3NdAaDzI2kaDz1DKdPHxnRgPD2w9d2u
pmqnenh/I88oXzpE7Bx6gH+Y7ygydJKx25SJYoxuy5fx7lyo+3xWrUVMZABABIq9LWNNB7TKcv9s
RXK3Al+Ch8UpW3cIoTGNO0M4Mv5vKPfOo9+29191pgy1Vk+Fy6d79V4uxO8n3s7ZEopx1fKDWHxf
mskIzFSW0fzQ5tTQ/vS4ToO7HEuEoN/FjqdEcYJOpQ2sXphh8c9eSBsSt08Yf15u2/PDP9HThvVo
vyZ2AjS0Ha05q5992OQc0mxZvsYhwhTpKCy5IJkpUnwOw/Gpn2bbzwoB4pU6BaDzSBoVKg4mpEE0
VPeoRx6OIb0gKIWnIcMT5ztsL6Et9PP8wELUTnKeroYC2JSwMfn87d3AIfmsyVPAlP9ZzIbq4P3u
7egMQ85f/FfZ9xgEg+Qzv9r6j2pEHW+d251wptoXakraYOSWnrymadyjAWs6Z+1H9MW/iw12NxGY
791YIIvaZftRPGoKgh+Hc4x2aS8HshcMoCVqtciJaCjVAheLTnhLUhOiOoCefRuVNJHkQPNNM4CU
o96RQtHOxh43sVwCHXRv4F8tZmd2qwmIiqkZyL9MOzNcv+IYb3HYXFfDSHQ8cR+T4Mpt0HjMZsGL
sv3ag/d+ae5oZa5ZPGp9SuPrXYDowfk9CtUzkkXB/2kkWmgm9NcTeWpYvIgj1faF2jiT2im5jlYZ
aoe2+BrLo4fY/mD/RMEyf4y5BGeKaEgzUlVSmukeQ9RGkS2IhOsBxpTFGTJcef689m8FnxYDwtQO
FJFZqwuGpCo4wEBTAVrWzukDBMUPAtAdg0bLHk5lBI1w/Y+CFSwLPMKS/J6kKmldReVwOTuOKtGm
KK1NN34nNKWpuvcl7bmcc90BuBkHsthF3hYZyMKD9flBUuQXOCOxVR+X7wXx2Xg2PSYeCwAOxi+4
qNhEWoMAl3c2nGnXHFAVjUd0brB63OjC396iUCdBixSar+a78vzjRWfVKQHauLZhuZRcwPVSW3/B
um21aznvel7OoWhy9OIENr4VmQmlMtYyDnyEXOVLn44YQGEGpISuyZiF5aDvqLk2HYmZymgkywyM
fIHiH9dVRfjQUpRliZ72VcMfIduKXiXNaAQ8t9Cvn8/28Yh+t0E7nbl6zCxdqpd0UEtls4nWqcCH
4M3BZ19P9+YRAHvFjbeDXpWXHwO3p9FN/XVt6ffP1PVqoS1Gel1gvc56nDCLYmCOFqYS8iKiXPs7
Tl2Hwmw55XZfmcRnsu1q4nBIA9KRdPgcE7du+21M9YB+vfQvID61tp21Lqj/wshIdOmfEG05bG9C
uHCYEEzcKRUh318/kheC2F8L3Qpor0ZshckDLeVNKRpCBjYb19tcILjXuLjfSZ8V7I55iGquuXdP
DdGXxqU38HmuvmC92WgLHkZIHaDqgx6oYWrJz86RKxAJElKNIn8vwrTOP6VWnE1g9pEE55xTyQdG
DVts7/Qr4dTkCjF+gxO7ZyjaTVpT5WT5JH0EP4qa0UHdJkPyGK4+rxVd3QyiWFumB9vNJFgLG8Vp
Nz9K8HdM3kSBiy4baKkT0TRvBM+MqL1sgMidAopFwU7KpB2tXeYhA1pEoWrhESGIGSEK+s8JEiCD
mNCin3vKW9YqsJbcYe+jEbxgq4EhyNaTPEMXD01vnAtX48ix+53JKhexCBTJdacee8BrIFSkE57+
0WtDA3ZrK41AXZgTepJ2Y9FovN2xhBz+CbKAAeIGr33gEI7MPsONzCybGa5LCS2XRvoLgv8XGB8V
g+GnbxW67oHg5KXj+hy61dqEFY4KwXWZ2ZhlgDQU5Zw+DGGxc5QLW0RDosNFYo3+PzRWbvxt16FP
L3D+0c3x17oio2g/jXkWMwSA20VAMe6D5kIJvdzwieE0Qvj0sJJIMB77KwDXsxE7xVXELsN/iVmi
Ha9unhWGwG+F45EEB3WhcipAUHpymU9GdpuHSnHEU5JGPpfmSoZ0hv7KAD1COQua9Juda+xYk9yP
biL6KAIhn5vAoiym7MkxD7kpKzlYrWrFsBXzj3FIQFm9J5HpZ914rItmo0+717ktA6HCBc0fq4zs
O5ZOeopePg0zwBtqQxOvYW6BFYMtJR/FOSDANYCGrXSvO24G6JOTMD2s6rBEmESn/DFk1hZ59TSl
zMMR0GnTA2GPvjlEd5wKsd2P4F8zNoDEk8y3s3TQbMpoInEf6BilwDNwBT5leGsQwdbILwQjHGie
Cx4nTjnsMkVatqlM3uOVIt7p2iuGnxNuNod1QHb+fmPyz/5SXacidQHybmRG7l8INHApIXqQMS7A
BLUtTaDg7sfCzb1LASHb0DUPU4HkuKwYrGQaeeQQQH/zkg1CXfi=