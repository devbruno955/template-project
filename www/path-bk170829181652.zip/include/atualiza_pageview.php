<?php //00e07
// *************************************************************************
// *                                                                       *
// * VIPCOM - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *
// * Release Data: 30 de Agosto de 2012                                        *
// * Vers�o Classic                                                    *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email e Msn: atendimento@sistemacomprascoletivas.com.br               *
// * Email: suportevipcom@gmail.com 					                   *
// * Website: http://www.tkstore.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n�o � um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran�a de  *
// * autentica��o por licen�a, uma v�z que voc� comprou apenas uma licen�a *
// * de uso para um dom�nio. Portanto, voc� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc� precisa para *
// * alterar, mudar c�digos, est� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom�nio,   *
// * nos envie um email informando o novo dom�nio.						   *
// * N�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica��o de um dom�nio n�o registrado com a sua identifica��o,     *
// * poderemos estar bloqueando a sua licen�a sem devolu��o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   *
// * Contato: MSN: atendimento@sistemacomprascoletivas.com.br  			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPrjxZIcMnNKERiWO2W+vKoTR6epF5ENs5DfJX1wGdNnL9RAhL7G5g1SNUMLNclEsW5Y+7R8h
OV+7qZSoUmzQYxhvL6eQOmZR6XyOCdP66FgF+C8El2rEzJ+QeI9/emBXpJiJpupqPJWSH3zVI5gV
PM3eHNOE4ifRhUW7cA80M0+n89jnDLLX7KY1PLNOct0xzB5nlp83ivx0oJIZnmZtAFES6dJYL6bp
r9HBDn//ZXLhyzrGO03BqVQKXwWTR6E053JQ0kIZ8MkKo+bldhRIl95GEiRj//DYnlcHezfNXxiG
K4BCeH5KMFQYEBjqzAMoZ15yKjY6EDyTb8zZ0Zx5ZsaVe6y4wmiz2952fGFgR9FYalleMyp4bFuA
DIIi5ycAMXe+d7nAuQcjC+VWUdZqQIutr8TLrbeHPwuiaK9gU2CAX2psQ5g2rooVBTVHNkpz5eCn
pYufSXQ8YVNeE8c5y++bbzvYIyy6qPC9MCRvcVg/CLPli1jkg2NZP8xQKGIsbcFT4ngkGykVl1Xz
sPlIu64b6rY+9g+tY0UsYgPNCsPKVrJPwhTNaybyWsYZNg9mbZ3lM+ydzgzsQOkL