<?php

include "../app.php";  
atualiza_click($_REQUEST['idoferta']);
  
?>