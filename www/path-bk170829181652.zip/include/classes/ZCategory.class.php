<?php
class ZCategory
{
	static public function GenCoupon($order_id) {
	}
}

 
