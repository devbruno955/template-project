<?php
$value = array (
  'acc' => '',
  'mid' => '',
);
?>