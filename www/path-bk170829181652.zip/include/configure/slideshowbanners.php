<?php
$value = array (
  'ativo' => 'Y',
);
?>