<?php
$value = array (
  'token' => '',
  'enc' => '',
  'acc_id' => '',
);
?>