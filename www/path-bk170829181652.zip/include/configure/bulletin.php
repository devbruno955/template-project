<?php
$value = array (
  'topotodos' => '<p><a href="https://click.linksynergy.com/fs-bin/click?id=9Lo6SJdk7Mw&amp;offerid=675980.26&amp;subid=0&amp;type=4"><img src="https://ad.linksynergy.com/fs-bin/show?id=9Lo6SJdk7Mw&amp;bids=675980.26&amp;subid=0&amp;type=4&amp;gridnum=16" border="0" alt="Santander" /></a></p>',
  0 => '<p>Publicidade:</p>
<p>&nbsp;</p>
<p><a href="https://click.linksynergy.com/fs-bin/click?id=9Lo6SJdk7Mw&amp;offerid=681639.8&amp;subid=0&amp;type=4"><img src="https://ad.linksynergy.com/fs-bin/show?id=9Lo6SJdk7Mw&amp;bids=681639.8&amp;subid=0&amp;type=4&amp;gridnum=13" border="0" alt="Trocafone" /></a></p>
<p>&nbsp;</p>',
  'bannermeio' => '',
);
?>