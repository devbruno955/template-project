<?php
$value = array (
  'mid' => '',
  'loc' => 'BRL',
);
?>