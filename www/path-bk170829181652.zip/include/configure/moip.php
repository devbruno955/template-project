<?php
$value = array (
  'mid' => 'jlferrari@gmx.com',
  'tokentrans' => 'HKRVWRR66AFSJ9HCMR6CALDZCRM4Y7KM',
  'chavetrans' => '8FJNJ6JWT7G3XJWSZCLQVMFFBHE4LOAGJVRHVEPS',
  'urlmoip' => 'https://desenvolvedor.moip.com.br/sandbox/ws/alpha/EnviarInstrucao/Unica',
);
?>