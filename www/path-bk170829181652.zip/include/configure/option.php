<?php
$value = array (
  'termosobrigatorio' => 'Y',
  'noticias' => 'N',
  'bannertopo' => 'Y',
  'bannermeio' => 'Y',
  'mapa' => 'N',
  'cidadesdestaque' => 'N',
  'debug_sql' => 'N',
  'bloco_googlemaps' => 'Y',
  'rand_popular' => 'Y',
  'moderacaoanuncios' => 'N',
  'bloco_tkdeveloper' => 'N',
  'anunciousuario' => 'Y',
  'modulopagamento' => '',
  'cpf' => 'Y',
  'tpvulc' => '2',
  'paginainicial' => '',
  'conteudo_oferta_popular' => 'Y',
);
?>