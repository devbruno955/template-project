<?php
$value = array (
  'mid' => '',
);
?>