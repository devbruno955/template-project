<?php
$value = array (
  'pay' => '',
);
?>