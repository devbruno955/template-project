<?php
$value = array (
  1018 => 
  array (
    0 => 'team',
    1 => 'order',
  ),
);
?>