<?php
$value = array (
  'host' => 'localhost',
  'user' => 'root',
  'pass' => '',
  'name' => 'sistema',
  'url' => 'http://localhost',
);
?>