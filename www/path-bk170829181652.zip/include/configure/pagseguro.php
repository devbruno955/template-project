<?php
$value = array (
  'acc' => 'suporte@imopolis.com',
  'mid' => '9304E8D298894CC199030B53555F5E71',
);
?>