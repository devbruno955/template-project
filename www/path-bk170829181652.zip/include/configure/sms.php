<?php
$value = array (
  'user' => '',
);
?>