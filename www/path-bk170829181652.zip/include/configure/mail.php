<?php
$value = array (
  'from' => 'atendimento@imopolis.com',
  'bounce' => 'bounce@imopolis.com',
  'mail' => 'mail',
  'mailparceria' => 'parceiro@imopolis.com',
  'helpphone' => '(91)985250808',
  'helpemail' => 'suporte@imopolis.com',
  'host' => '',
  'user' => 'admin',
  'pass' => 'Letici@2017',
  'port' => '587',
  'ssl' => '',
  'interval' => '10',
  'encoding' => 'UTF-8',
);
?>