<?php
$value = array (
  'background' => 'N',
  'intervalo' => '10',
  'velocidade' => '9',
);
?>