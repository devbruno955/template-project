<?php
$value = array (
  'fundosite' => '#eee',
  'textocabecalho' => '#3f3f3f',
  'linkscabecalho' => '',
  'cabecalhofundofiltro' => '#d20f1a',
  'fundonomecidades' => '#0796b6',
  'rodapesuperior' => '#555555',
  'rodapeinferior' => '#333333',
  'fundomenunavegacao1' => '#828895',
  'fundomenunavegacao2' => '#303030',
  'bordamenunavegacao' => '#4f5058',
  'fundofiltrohome' => '#471516',
  'btanunciarimovel1' => '#aaaaaa',
  'btanunciarimovel2' => '#303030',
  'btanunciarimoveldestaque1' => '#fee52e',
  'btanunciarimoveldestaque2' => '#986218',
  'btverdetalhe1' => '#f97b15',
  'btverdetalhe2' => '#d56305',
);
?>