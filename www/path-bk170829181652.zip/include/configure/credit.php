<?php
$value = array (
  'register' => 1,
  'login' => 2,
  'invite' => 12,
  'buy' => 0,
  'pay' => 0,
  'charge' => 0,
);
?>