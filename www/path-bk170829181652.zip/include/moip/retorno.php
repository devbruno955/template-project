<?php //00e07
// *************************************************************************
// *                                                                       *
// * VIPCOM - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *
// * Release Data: 30 de Agosto de 2012                                        *
// * Vers�o Classic                                                    *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email e Msn: atendimento@sistemacomprascoletivas.com.br               *
// * Email: suportevipcom@gmail.com 					                   *
// * Website: http://www.tkstore.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n�o � um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran�a de  *
// * autentica��o por licen�a, uma v�z que voc� comprou apenas uma licen�a *
// * de uso para um dom�nio. Portanto, voc� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc� precisa para *
// * alterar, mudar c�digos, est� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom�nio,   *
// * nos envie um email informando o novo dom�nio.						   *
// * N�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica��o de um dom�nio n�o registrado com a sua identifica��o,     *
// * poderemos estar bloqueando a sua licen�a sem devolu��o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   *
// * Contato: MSN: atendimento@sistemacomprascoletivas.com.br  			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPrDoE3rOwe0o9BYj7cPaOX6HkgJQk6bN1k4ukDFYVMHGbOHPofIGIJq09wzGyu2tyk6LRKX/
5N6PRA1AIXqB2sgfNEVusvWpbIxPYlPGVHg2/g62W1qQ2ilVyMA3uwFuTu1GcsrZgE6oVmls7i3a
/TEx/6hi3Bsocns3zp7ChXiAAXSJtqJ4LlQn8w0Q7jYPwAL4bmLqRN7h48Cu9Y9beCp34Ll3ggZK
WaCZVtjTVck8Oo6TR3096Juc5AtboRPIuCM3RJ6Z8MkKo+bldhRIl95GEiRjrsdBiYHn0G4kpzXQ
KD9/uK36h/xpUSyoGGRhOL9Bj2j/uL2Hfk3j43x42+Iva4+TD0oXhWsIEsw/FTnVhOyWRk7Bz8Wh
zXRC6NB5C4LEtmeCRQXZfaHXvqy5/8nYX1ckovqm7cYBfhzaVPg01DSu4hfhogN6WxCI7xYMm8/U
uChx48OGzcxoyAarpY+95HaSFh9+hB4vUjORq/E0uQASblWvrYtYprA3AKZX5lRQok3qEw9bVusq
FbQ/p/7zVQI3WzeRjSqYKVFDe99kJAjOX02qIaNBRYIkWFKXEFpurP9BRlX+J58iuza6AHpUr4m3
rL/oYgTFLCRPhnO/ewtAyyKYeiRWJBVLnw7MpdcY8DGzWtgsIxyx4XfsFTWRnDCX+3O4n9OYf+zT
fgKGPvp1g6fIL0LZgrD3I1L5HYevH4c+eBSM5a0PZLQMKL/Dw083Ckm1mvE2Oo/BTZZuxamRvqW6
qmv929JSti8qSYVFMM76Bu/HsSbMIMi4QlA1huOT5qPI76UjrN0Qh59DQ2rYCjNbNiVDHL+LumKz
tRWLamZs3sPxf09oEeTGdECOiH7hkeCqIzrSoPP0Sougcs/n9BI1lTfi5xThRhyvgFX+O9E91QWI
LukcO3+U6qhK0ksDOnnO47BF9+b7NpUFL+xFIyhyXEBZ7sfDtGR11uPkKtp4RFR+OFe/iAD0yhVj
zNZOoavZ7rMxoN4JvjY8JaCqJDJ7JOO0eg7blbz7s8ic+D5C6mrvmGW4dJ7+UUmWc2q5PEEMrKCg
ya/i5Kw1zcdFbwAWxIzeGcCM6KGSmSIGU/ajo+bsT3RJw5latlpLuMrYBQ7lofRLl5WAn/oju+Q7
rOACSG++EckSWNYdyB3QNU1MZIOOP7nAdHgO8BfIXAKZzjACZVgA2CpoKRUoPizQYS4SWZENpNQT
VNRki1C+OoBVXyQU9he865mV7f8TsZIPn7e2c2OgugV6ckMufvJBJKK/rKko4nNge/GrJ7gdCaq0
hDtV5FRumLYtsL25Ra8LaoLN6AW0/8qKUTNOfCzvUMpMuHLTJhf0ZEr9eNC9soSePjMsIoRtawK7
IOYj45H13cn0X+/AuATdrNn5YB2DFMDq1dK0GZilNPPEVWCSxw/oFYqEAKEaMirFr/iKt8pC4eIC
hyKOR+kRTCM3SkgjpqGrHS27/ZghR4jkZ0vgcQwcEnl0YuiqjuSjazcWTrFevesxIdTIft3voBdm
Tc0mjq57/V8GmKFD3A0qwGqefWuC66bkE5C7VC4nmxbsLHakZbeB07s6XXKel8OiC4TflNnxWFzr
lR/4ns+cs8a21fmRDGPcRgmOjsFRvghvJAZinn3RW0bUpG/PZGgrgL/XP+N3QstVUAgwXBY1qjMM
iZVzu63b4TvR6BZTo5wL47TxnxeT4+Ig5/v60CL+3AQKCqotW1lZFgMy3Kqn/8BBO8+yPyQLgJjj
5rxza50bDTnex4KpN+14xAM8tGKhc9IObNBbTT1/PGOEJpfQ+aPsbNAqZEPTAUVuCZFlb36+5vkG
1WLHnR9S5sGMlRzzcXVJT5geB5xhUEwyHdgLTMS/5D2dCdVVcG4MFS403uq+EBnCAVBx67nAplCA
5pHHq/qiYv30qlUN+btik+j26CoL5k2BEaA8Q8EjZS6Ue3O5OgM0UigrV0l4ycgE9AqmDJjZ667T
jDUdWN++Sn+/O+SP97uJqEmA6ZTTWREJgKiQEuAHG714cGO8jJSYXhYrByyiFYcdkjjb2lytD3Jd
nRGzSa4+2GDJse8o1Ogehe44fL4F81SLVZOufQPPgr+JiIWlPc2KX1mqAwlwUXIsU+UNXL7AVZUG
Nc3PDYsb52VUq1VcVQIoiR5pryHr8k9aK/W08C9bKpHGL1RYYKlgugtBziCtd7EsX1IqQXdfmGGw
HbV56PIEiV+svcYZFT1Ae0WDu5oo5sUveRD9S/py9W2IY/c49lcaEzd0lURk/2/LMa8agC9an5oQ
0sVHHqfUnZiCzaRm1eQtyLw7sf5Iu+XErIQXAJ2F1w9P8hgDtfLPBzjgvjBSCgQDlKmEER2Q3Y0n
xQ6rZtwrYd1r+1Kgi5lI3D4jak5x5U2cegZBv0+qund98oJmmIyXn/SvnvAfCVNmnkXxtu3ntYR/
kOYzG5EAZRo3K2gghRU3UcfCYOdFZaKuHNlZVonA7IajQTNJYd+NAIdVeHVp6qZI42xV9qnRudpi
3G39tOMYh61l0FqS6vjIzR/q88bim29/bN17Q9T76UA9rzsTwX8KAWs2i/9XHPFsuyxEo6rJCMiH
UibmXSSFqRs/2pNK0L8X74C4ppW8azgu0CWELEQIri6PYV6PDglIZxv85m89zSUgSjOGKvqQXhDp
VivKfiilNPQvYDCFCXYyMZV2SG4ov7RPXZQWMDr27FMFs1Og0DJwK0sjeeBuiMWOxtXIg6R2An+U
rH140f2KJ4K6ypWfNBjl9NX0A0ILKifsTd/WhJCaXuRckSUuifSpYIdfy8KaHtIIKqMyU6i2sIUb
mAgjS9HG5YtRLSeG8sjMGLuxXPsCh6OZjqa72AhENJ+hC8DxwXmGUdDOK0uDzjqtDSzPwT6S/HPX
lvsu0xrqRG==