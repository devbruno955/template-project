<?php //00e07
// *************************************************************************
// *                                                                       *
// * VIPCOM - Desenvolvimento de Sistemas Web Empresariais   			   *
// * Copyright (c) Tkstore Ltda. Todos os Direitos Reservados              *
// * Release Data: 30 de Agosto de 2012                                        *
// * Vers�o Classic                                                    *
// *                                                                       *
// *************************************************************************
// *                                                                       *
// * Email e Msn: atendimento@sistemacomprascoletivas.com.br               *
// * Email: suportevipcom@gmail.com 					                   *
// * Website: http://www.tkstore.com.br                                    *
// * Suporte e Ticket em http://www.tkstore.com.br                         *
// *                                                                       *
// *************************************************************************
// * Este software n�o pode ser fornecido ou disponibilizado a qualquer    *
// * outra pessoa.
// * Note que este n�o � um sistema criptografado, apenas foram escolhidos *
// * alguns arquivos do core do Vipcom para implementarmos a seguran�a de  *
// * autentica��o por licen�a, uma v�z que voc� comprou apenas uma licen�a *
// * de uso para um dom�nio. Portanto, voc� pode personalizar o sistema de *
// * acordo com a sua necessidade, basicamente, tudo que voc� precisa para *
// * alterar, mudar c�digos, est� nas pastas app (contendo html e php)      *
// * js e skin (contendo javascript e todas as imagens e css). Para troca de dom�nio,   *
// * nos envie um email informando o novo dom�nio.						   *
// * N�o disponibilize o sistema para terceiros, amigos. Cada			   *
// * cliente tem um identificador associado ao sistema, caso recebamos uma *
// * notifica��o de um dom�nio n�o registrado com a sua identifica��o,     *
// * poderemos estar bloqueando a sua licen�a sem devolu��o da quantia paga*
// * pelo software.                                 					   *
// 
// *  																	   *
// * Contato: MSN: atendimento@sistemacomprascoletivas.com.br  			   *
// * Atendimento de segunda a sexta de 08hs as 18hs                        *
// *************************************************************************
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');if(function_exists('dl')){@dl($__ln);}if(function_exists('_il_exec')){return _il_exec();}$__ln='/ioncube/'.$__ln;$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}if(function_exists('dl')){@dl($__ln);}}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the website operator. If you are the website operator please use the <a href="http://www.ioncube.com/lw/">ionCube Loader Wizard</a> to assist with installation.');exit(199);
?>
HR+cPwwZ9UmPE9x3vMQmptl3aVVTFHskCdeK5Sb3OL1jiBxxHDw21J0iYK1q1ZuGjgB+tObG4wMS
Im2Z+42jc9FzIZKQs1+CoXlzAmFBELranfN+iiHqhnQpWV8DVCLRL91rdSI/skGtVaqfs7Y2z8Ys
mSAJqf42vTTnBEfca8nofVolNj1xViLYQAlQxsJ7oi+e4UP/Vt/IAG4zia/J9x26UgSwe8h4zXJ+
dE+RraXxrOBQhmwGt4cAMyQP6eemslx+YyY0T7gZ8MkKo+bldhRIl95GEiRjZtCuFX8RxhG3Iv8A
K5gXstbo8HV9d93TC4hFq7n7kpkldfHIC3MEnUtipAOv4HTQE6PLGIbZ5uy+p8/LdTFOQ9jqnDSO
RgyPYX1NhOdXaruS6MePdIkZRz0J3Iakq2VYOjkwWSr9hvx91EF8eRAvCKK1e1/Gq4OBHeSe1zfP
HPhYvSdhcNTuZAJRNm13iE+le+oEvsxWg6IqsRsb4XqKqVsVL9JpVIlTsgicUyQLpHUer0K46zFH
ZZvpPXDa3yccphTkIntQ+foNllBIpeKjnOYre/h1d+Qwafvb18vXTtdgfbKLRlrMrUFvtbyGvnhb
UCTwS3SpqlvJ6PMiiGEbpl5QshDGTB2B0jmz6XLnouy5dGyuJ/lgXs3uABHhrRn+HhjYi6r7iVVV
rSf7BSTNMI/j5gKLTQSrqnuPYmNrhtv52IVuTIzpMcsZrTXA6BBiSoAoDuxSNrq+mu2OQFVvbz0b
haSDUrvcFqyu9T0tM9mYw6Pw0dLJ9G7TVLYsuMWv49QhE3KdriB78uoE2iWmtisSQSjGFnoLqP95
0F1y+c3hV5Oae0PTsU/6eQqmOtAmrK3K+5+NliqFCglrq4U9G0I+36OBulhLWVZGNy+wt9u4Bup3
uh+zN7K2LovD3NLoQZLarf8b8a1WtzWgEHXWgo5E80A7LRfupAOJJpFSeNhy/6zTj3se9jnbvmw7
T62cUu/UWjut0YHFFr1gpc4OUtbwZ8v8SJ2rOoorkyBibOeK7fpAcgCVl2NhlV0iJsWqU2mUCewW
bWdp3suzIX66RrNdD2ZBfT6NapNE/ZPCRu0EkY/gVmsDawxR+9+9DAv8T6bC6UOaUli+XsXoSl3o
i5uRpq8emnoSJKPW+1yo3BQ+9z2NzRK5iXy6bEJaNdXxloRtP1Mo2ghU9VFfS6ekmAcZlh6kFWHU
6ayciWsyy0eko6wAvoBs0MWUMhNBVPC40se2IFBT+NR3wgYX8ul+CwmKgYsoeE4v/NpLHLLsUGuq
/g5soPFLHFc6nK5nw+uNNhZMgjJ1JFoloukDO4Pr0gMwR7Rv9uoOLpKXnsObEEJaBOTI5/kNZXs6
3rDYwNkaET6TwzkqTX3/6BYWMPSX/DjGgjcuxfUy0nut9Zdm/ND0ohqYwKGfXNTdWK70LOQtIMVm
BFOTIR+tjKYHSG+nTcZCwsuvc3HGRWiLjR1LKBjjXg9l3WKpML3iCrcJSpdfqx1Z479g60WmWOw3
Ky+pYuV+CtvmAr+w6r+2jexYj9EHYbFtuaOR19syz9LVFyjitlS7Y9a5DWC05qarNbov7yH0LJwL
5Qlej4MqL8T6H4IOku0GgBxWm5x/M0k37QoMV/kK1bWwjl7aQxxRe2Pf8rqx1OTO6reINrDZnxEo
bhD4ulkIxzhB1o5WyMujT8Vm2NN/JNuQQmisodh5PjhyFbFa3mjdZxNVx3BlL/FbJlMUTIm1pOpV
5yx2cQpo+HKn2nvdMPOo0sfVlYy73XTv+dH+E74q4qX9LQ+aPa/9UCAxI/fI07v8AXag3x8Zi+UV
SRPvqtwbSr7YESwsurbhfAGwzZ2oiJrENfiqbmz76u+Jz4EfFyQHq2FRo0iVKLOGXzT+eoo5ZLU0
M5pvLuhWZv8m4p4mEqtTX640jLXOVM5Xsy+WJUbKFoVD6eAuvH3AdwXa4iD1MEM5OquJzb5fa0L2
1L1z4YbTn0/9aWn7nkCko/nbCLmrMj74zX/hdsUB2k2OwwHrzPUUSXDHGQ3b4/dhMRR4HDthNlzX
kODmF/zY/nIJSBTIBLqRYQkm08ACumMC8AGUhpAEp3Y7vbHYflBbRqiWjfPP2yLxSSw4avebt2RF
vF/YJ/2p1vtKIxgr9BwfzTRw0YZVHhkxYIjDpOnzKWNwxycc1OQF2g0qo374fWpJjbLBGM+l2exO
Vsw0Qt7QF+sC6QEqr5N+x0IQ7/S35eRFGELDdqjcdKS7lTvl/cgGs3ALmlqpzWpsyilDp5zgkC6A
KWvrOt90F/ooQLIsds4GlSregZRN4JkfeyUb5ZjrufTzV34ODmk/JbUVnYb8QwGbOiUjlMx/02ec
K0USFS3x65abBzPGbzD6wIKO0spf0jx/TWvVnLXvTPvoA8rDWuZQyO+1m6OOQ90JEmJzzIhPW7jd
ssLMvpRSWSUoGcPnK7mM26QIKnyZHl5xY8N0eY7riRgt5r3W33MmhMardGHkaohSIE2m9fs+XH6V
snb99P9JNcLnv66nKZR+hO9bUzQ2VgVhj/KGGVTQSb5PEviKzMZMSn83tQ/gGw9E3xg48x+HBGRe
xNV8USgOKf2wuszifRVmvwBUOfbE7sXVxvTgFZPvlGwGw/jtbrX07PO/Rtftmaob0zIoxk/pYe5n
MKjLAeIujMVvYp3BrJtB5ErZshanRNqZrGKQ1oAiKXe/kpa98VOtkzeir+/bvbQj5WrUQuBP2Ixh
mRPDch13C9hjteSA6m6DdWPfm2vO1OKHYsvoBhIzXScKiQ448ObIvR331GlqwG9vdMC8kJ7iVMcI
mGbZ6XXrsqISOJ8Lq0V19zY1YVzfrbonvKkT2kdeF+X+IrhTNboSLmwJ/95DuPcKwLN1Lfl29DwG
tRFEvHaZYqbydNqHrixsJFAVftcnBQ0XhBCk3joOcE5SsnsW7Xwuvn+6WQjASU31kAtAar0wzYGS
yDO4d4FzuRoG4fFdumAnlY1wNPMfp/dFxxj0eQXjs0Nb5dFdZA9Mfl1RZ4TP7tdD0RbMhufA5x/w
BYMFHe/fKkddE+/H8JD7+hKPJdMlwNgxiGj5QUwwFUPkWPm4AruoLykCFJjqQGu2HMZJceHxrVAC
5uZa2OdAG/1CBkD/hCOXzWQe+qtp8Atg5GXjflfn749IwMtspVjyZi4EUqNqnIOXpPac8DKVHZ9Y
FKOYVL/N7wku9IZH15HJn8bv7fIBt6Sv5CLFaC56IIw5QbUvFW/HnMlI3r5Z24e5vfmLAofbJhDT
C6RM69FqXttKmr+Ecmo3D5+4IunyKA7Gejqx6qAOGdIxnlkZqxnCpQZYuOJA/N9D1Q9lT7ieuB/r
PrN7qMXbCJehxs/sesQrd36q89VOnyDgyL8AB1UvxHAGFXFOr5LyNughZLsJ+vY0g+sLpem937SN
NqJTusldNnCXAbhDogrzYaJyzUDa//E+s+dk3QiJ7WprwZqETLxqGHuMsbLWQrM1GFqnTz8sBMnO
PycOYXf+uBZdvlVq1itW3r8+WxsfLDG9yuDLgm+SwTvUJHlBC52V2E6YC2o68EPWnASMDf9wYpyz
otPdgSlXuQcwzlQIgW+GlcydSCzn5AF9ZLZR+8UMIIe5hQkoo06ycD77aSCqG4bzAJqbFsPZyuED
dNkDExlHgm57gYDncojCOGhyiqHJnYCl9UpqGerFX99lCX2K67a3+XMUyRaRnGx+DqCP0r9ncbjf
zqTcmKA8fvzDsT+ZX4mCtGvD2mTSLpAMnxIKeS6ommNSXEE9Y67ZWjBrE9cVwDEJ9dL8Qmd91NWA
ovPuLEDwHex0K0LfG09Ke9XIk7eoTkYA+SjbKtj0BGw4DHy46LDPqLDl5pgXuMEUZDPfo50Q/up8
d/ruljCRUfoii/4phPG=